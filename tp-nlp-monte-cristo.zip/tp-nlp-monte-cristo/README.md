# TP1 NLP — Analyse du *Comte de Monte-Cristo*

Master 2 Intelligence Artificielle · Traitement Automatique du Langage Naturel

Pipeline NLP de bout en bout sur le **Tome I** du *Comte de Monte-Cristo* (Alexandre Dumas, Project Gutenberg n° 17989) :
nettoyage, tokenisation, fréquences et loi de Zipf, stop words, WordClouds, stemming, lemmatisation,
Bag of Words, TF-IDF, similarité cosinus et mini-moteur de recherche.

## Livrables

| Quoi | Où |
|---|---|
| Notebook exécuté, avec toutes les sorties | [`notebooks/TP1_NLP_Monte_Cristo.ipynb`](notebooks/TP1_NLP_Monte_Cristo.ipynb) |
| Rapport : le sujet complété avec toutes les réponses | [`rapport/TP1_NLP_Master2_IA_Reponses.docx`](rapport/TP1_NLP_Master2_IA_Reponses.docx) · [PDF](rapport/TP1_NLP_Master2_IA_Reponses.pdf) |
| Code (package Python) | [`src/montecristo/`](src/montecristo/) |
| Graphiques | [`figures/`](figures/) |
| Tableaux de résultats (CSV) | [`outputs/`](outputs/) |
| Tests | [`tests/`](tests/) |

## Organisation

```
tp1-nlp-monte-cristo/
├── src/montecristo/            package : toute la logique du TP
│   ├── config.py               chemins, sources du corpus, stop words du roman, paramètres
│   ├── corpus.py               téléchargement + cache, extraction Gutenberg, découpage en chapitres
│   ├── cleaning.py             clean_text (corrigée), version légère, séparation des élisions
│   ├── tokenization.py         mots, phrases, bigrammes, comparaison NLTK / SpaCy
│   ├── stopwords_fr.py         listes NLTK, SpaCy et personnalisée, filtrage
│   ├── frequencies.py          top N, pente de Zipf, rangs, hapax, personnages par chapitre
│   ├── normalization.py        Snowball, familles de mots, SpaCy (lemmes, POS, noms propres)
│   ├── vectorization.py        blocs, BoW, TF-IDF, similarité, classe MoteurRecherche
│   └── plots.py                barres, Zipf, WordClouds, heatmaps
├── notebooks/
│   ├── tp1_nlp.py              source du notebook (format « percent », lisible et versionnable)
│   └── TP1_NLP_Monte_Cristo.ipynb
├── scripts/
│   ├── build_notebook.py       exécute la source et produit le .ipynb avec ses sorties
│   ├── build_report.py         remplit le sujet .docx avec les réponses et les figures
│   └── reponses.py             texte des réponses du rapport
├── tests/                      15 tests pytest
├── data/17989-0.txt            corpus Gutenberg (cache)
├── docs/sujet_TP1_NLP.docx     énoncé
├── figures/  outputs/  rapport/
└── requirements.txt
```

Le notebook ne contient que des appels et des affichages ; la logique est dans `src/montecristo/`,
ce qui permet de la tester et de la réutiliser sur un autre texte :

```python
from montecristo import cleaning, normalization, stopwords_fr, vectorization as vz

nlp = normalization.charger_spacy()
blocs, noms = vz.blocs_de_mots(cleaning.clean_text(mon_texte), taille=2000, nb=None)
vec, X, _ = vz.matrice_tfidf(blocs, noms, stopwords_fr.stopwords_personnalises(nlp))
vz.MoteurRecherche(vec, X, noms).chercher("prison évasion trésor")
```

## Résultats principaux

| Mesure | Résultat |
|---|---|
| Roman (sans métadonnées) | 727 635 caractères · 121 600 mots · 31 chapitres · ≈ 405 pages |
| Tokenisation NLTK | 123 589 tokens · 11 973 mots distincts · richesse lexicale 0,097 |
| Loi de Zipf | pente log-log **−1,14** (valeur théorique −1) |
| Hapax | 6 055 mots, soit 50,6 % du vocabulaire |
| Stop words (NLTK ∪ SpaCy ∪ 20 mots du roman) | −55,7 % de tokens ; « dantès » devient le 1er mot (777) |
| Stemming Snowball | vocabulaire −44,4 % (11 526 → 6 409 racines) |
| Matrice BoW / TF-IDF | 20 blocs × 300 termes · 53,6 % de zéros (89,2 % sans `max_features`) |
| Blocs les plus proches (cosinus) | Bloc_17 / Bloc_18 = 0,71 (scènes aux Tuileries) |
| Requête « château if prison dantès » | **Bloc_14** : transfert de Dantès au château d'If |

<p align="center">
  <img src="figures/07_wordcloud_roman.png" width="75%"><br>
  <img src="figures/07_personnages_chapitres.png" width="90%">
</p>

La carte des personnages par chapitre montre la structure du tome : Marseille et le complot (I–V),
Villefort (VI–XIII), la prison avec Faria (XIV–XX), la maison Morrel (XXIX–XXX) puis Franz
sur l'île de Monte-Cristo (XXXI), où le nom « Dantès » n'apparaît plus.

## Points du sujet corrigés

| Problème dans le code fourni | Correction |
|---|---|
| `split('*** START OF THE PROJECT GUTENBERG EBOOK 17989 ***')` : selon la version, le fichier contient « START OF **THIS** PROJECT … TOME I » → `IndexError` | regex qui accepte les deux variantes (`corpus.extraire_roman`) |
| `clean_text` normalise les apostrophes ’ **après** les avoir supprimées | normalisation déplacée avant le filtrage (`cleaning.clean_text`) |
| `sent_tokenize(roman_clean)` : sans ponctuation, une seule phrase | segmentation sur le texte brut (237 phrases au lieu de 1) |
| Union des stop words écrite avec « │ » | opérateur Python `|` |
| « qu'il », « c'est », « d'un » restent dans le top 20 après filtrage | `separer_elisions` + élisions ajoutées aux stop words |
| Noms propres cherchés sur le texte en minuscules | SpaCy appliqué au texte brut |

Erreurs du modèle `fr_core_news_sm` relevées dans le rapport : « Dantès » lemmatisé en « dantè »,
« signala » étiqueté ADJ, « vole » jamais reconnu comme verbe, « meilleurs » → « meilleur » (et non « bon »).

## Installation et exécution

```bash
python -m venv .venv
source .venv/bin/activate              # Windows : .venv\Scripts\activate
pip install -r requirements.txt
python -m spacy download fr_core_news_sm
```

```bash
jupyter notebook notebooks/TP1_NLP_Monte_Cristo.ipynb   # ouvrir / relancer le notebook
python scripts/build_notebook.py                         # ou : régénérer le notebook sans Jupyter
python scripts/build_report.py                           # régénérer le rapport Word
python -m pytest tests                                   # lancer les tests
```

Le corpus est déjà dans `data/`. S'il est supprimé, `corpus.charger_texte_brut()` le retélécharge depuis gutenberg.org.

Testé avec Python 3.13, NLTK 3.10, SpaCy 3.8 (`fr_core_news_sm` 3.8.0), scikit-learn 1.9, pandas 3.0, WordCloud 1.9.

---
Corpus : Project Gutenberg, domaine public.
