"""Tests des fréquences, de la normalisation et de la vectorisation."""
from collections import Counter

import pytest

from montecristo import cleaning, frequencies as fq, normalization as norm, stopwords_fr as swf, \
    tokenization as tok, vectorization as vz


@pytest.fixture(scope="module")
def tokens(roman):
    return tok.tokeniser(cleaning.clean_text(roman))


def test_loi_de_zipf(tokens):
    assert -1.4 < fq.pente_zipf(Counter(tokens)) < -0.8


def test_dantes_premier_mot_de_contenu(tokens, nlp):
    filtres = swf.filtrer(tokens, swf.stopwords_personnalises(nlp))
    assert Counter(filtres).most_common(1)[0][0] == "dantès"


def test_stemming_regroupe_les_conjugaisons():
    assert norm.stem("emprisonner") == norm.stem("emprisonnement")
    assert norm.stem("portait") == norm.stem("port")      # faux ami connu


def test_lemmatisation(nlp):
    df = norm.comparer_stem_lemme(nlp, ["allaient", "chevaux"])
    assert list(df["lemme"]) == ["aller", "cheval"]


def test_dimensions_bow_tfidf(roman, nlp):
    blocs, noms = vz.blocs_de_mots(cleaning.clean_text(roman))
    sw = swf.stopwords_personnalises(nlp)
    _, X, _ = vz.matrice_bow(blocs, noms, sw)
    _, Xt, _ = vz.matrice_tfidf(blocs, noms, sw)
    assert X.shape == Xt.shape == (20, 300)


def test_moteur_recherche_chateau_if(roman, nlp):
    blocs, noms = vz.blocs_de_mots(cleaning.clean_text(roman))
    vec, X, _ = vz.matrice_tfidf(blocs, noms, swf.stopwords_personnalises(nlp))
    meilleur = vz.MoteurRecherche(vec, X, noms).chercher("château if prison dantès", k=1)[0][0]
    assert "barque" in blocs[noms.index(meilleur)] and "geôlier" in blocs[noms.index(meilleur)]
