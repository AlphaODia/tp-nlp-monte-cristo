import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))


@pytest.fixture(scope="session")
def roman():
    from montecristo import corpus
    brut, _ = corpus.charger_texte_brut()
    return corpus.extraire_roman(brut)


@pytest.fixture(scope="session")
def nlp():
    spacy = pytest.importorskip("spacy")
    try:
        return spacy.load("fr_core_news_sm")
    except OSError:
        pytest.skip("modèle fr_core_news_sm non installé")
