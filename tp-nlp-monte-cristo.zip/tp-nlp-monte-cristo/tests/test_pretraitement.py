"""Tests du chargement, du nettoyage et de la tokenisation."""
from montecristo import cleaning, corpus, tokenization as tok


def test_extraction_marqueurs_this_et_the():
    for variante in ("THIS", "THE"):
        texte = f"entête\n*** START OF {variante} PROJECT GUTENBERG EBOOK 17989 ***\nROMAN\n*** END OF {variante} PROJECT GUTENBERG EBOOK 17989 ***\nlicence"
        assert corpus.extraire_roman(texte).strip() == "ROMAN"


def test_roman_sans_licence(roman):
    assert "Project Gutenberg License" not in roman
    assert "FIN DU TOME PREMIER" in roman


def test_31_chapitres(roman):
    chapitres = corpus.decouper_chapitres(roman)
    assert len(chapitres) == 31
    assert chapitres[0]["numero"] == "I"
    assert chapitres[0]["texte"].startswith("Le 24 février 1815")


def test_clean_text_extrait_bruite():
    bruit = "«Ah! c'est vous, Dantès!» cria l'homme... (numéro 34)\n\n-- Il est mort!!"
    assert cleaning.clean_text(bruit) == "ah c'est vous dantès cria l'homme numéro il est mort"


def test_apostrophe_typographique_conservee():
    # bug du sujet : l'apostrophe ’ était supprimée avant d'être normalisée
    assert cleaning.clean_text("l’homme") == "l'homme"


def test_monte_cristo_un_seul_token():
    assert cleaning.clean_text("Monte-Cristo", garder_tirets=True) == "monte_cristo"
    assert cleaning.clean_text("Monte-Cristo") == "monte cristo"


def test_nombres_supprimes():
    assert cleaning.clean_text("le 24 février 1815") == "le février"


def test_separer_elisions():
    assert cleaning.separer_elisions("qu'il c'est l'abbé") == "qu' il c' est l' abbé"


def test_phrases_sur_texte_brut_seulement(roman):
    extrait = roman[:20000]
    assert len(tok.phrases(extrait)) > 100
    assert len(tok.phrases(cleaning.clean_text(extrait))) == 1
