"""Nettoyage du texte (Partie 3)."""
import re

from .config import LETTRES_FR

_APOSTROPHES = re.compile(r"[’‘`´]")
_ITALIQUE = re.compile(r"_([^_]+)_")
_TIRET_INTERNE = re.compile(rf"(?<=[{LETTRES_FR}])-(?=[{LETTRES_FR}])")
_ELISION = re.compile(r"\b(l|d|j|m|n|s|t|c|qu|jusqu|lorsqu|puisqu)'", re.IGNORECASE)


def clean_text(text: str, supprimer_nombres: bool = True, garder_tirets: bool = False) -> str:
    """Version corrigée de la fonction du sujet.

    Correction : les apostrophes typographiques sont normalisées AVANT la
    suppression de la ponctuation (dans le sujet, l'étape 5 arrivait après
    l'étape 4 qui les avait déjà effacées : « l’homme » -> « l homme »).
    """
    text = text.lower()
    text = _ITALIQUE.sub(r"\1", text)
    text = re.sub(r"[\n\r\t]+", " ", text)
    text = _APOSTROPHES.sub("'", text)
    if supprimer_nombres:
        text = re.sub(r"\b\d+\b", " ", text)
    autorises = LETTRES_FR + "'"
    if garder_tirets:
        text = _TIRET_INTERNE.sub("_", text)       # monte-cristo -> monte_cristo
        autorises += "_"
    text = re.sub(rf"[^{autorises} ]", " ", text)
    return re.sub(r"\s+", " ", text).strip()


def clean_text_leger(text: str) -> str:
    """Minuscules + espaces multiples uniquement (question 3 e)."""
    return re.sub(r"\s+", " ", text.lower()).strip()


def separer_elisions(text: str) -> str:
    """« qu'il » -> « qu' il » : permet ensuite de filtrer « qu' » comme stop word.

    Amélioration personnelle : sans cela, « qu'il », « c'est », « d'un »
    restent dans le top 20 après suppression des stop words.
    """
    return _ELISION.sub(lambda m: m.group(0) + " ", text)
