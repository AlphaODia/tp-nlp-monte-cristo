"""Chargement du corpus Gutenberg : téléchargement avec cache, extraction, chapitres."""
import re
from pathlib import Path

from .config import SOURCES, RAW_FILE, NOVEL_FILE

_DEBUT = re.compile(r"\*\*\* ?START OF (?:THE|THIS) PROJECT GUTENBERG EBOOK[^*]*\*\*\*")
_FIN = re.compile(r"\*\*\* ?END OF (?:THE|THIS) PROJECT GUTENBERG EBOOK[^*]*\*\*\*")
_CHIFFRE_ROMAIN = re.compile(r"\n\n([IVXL]+)\n\n([^\n]+)\n")


def charger_texte_brut(cache: Path = RAW_FILE, timeout: int = 30) -> tuple[str, str]:
    """Retourne (texte, origine). Lit le cache local s'il existe, sinon télécharge."""
    if cache.exists():
        return cache.read_text(encoding="utf-8"), "cache local"
    import requests
    for url in SOURCES:
        try:
            r = requests.get(url, timeout=timeout)
            r.raise_for_status()
            r.encoding = "utf-8"
            cache.parent.mkdir(parents=True, exist_ok=True)
            cache.write_text(r.text, encoding="utf-8")
            return r.text, url
        except Exception:
            continue
    raise RuntimeError("Corpus introuvable : placez 17989-0.txt dans data/.")


def extraire_roman(texte: str) -> str:
    """Retire l'en-tête et la licence Gutenberg.

    Le sujet utilise split('*** START OF THE PROJECT GUTENBERG EBOOK 17989 ***'),
    or selon la version du fichier le marqueur est « THIS PROJECT … TOME I » :
    on accepte les deux formes avec une regex.
    """
    debut, fin = _DEBUT.search(texte), _FIN.search(texte)
    if not debut or not fin:
        raise ValueError("Marqueurs Gutenberg introuvables")
    return texte[debut.end():fin.start()]


def sauvegarder_roman(roman: str, chemin: Path = NOVEL_FILE) -> Path:
    chemin.write_text(roman, encoding="utf-8")
    return chemin


def decouper_chapitres(roman: str) -> list[dict]:
    """Découpe le roman en chapitres à partir des titres en chiffres romains.

    Retourne une liste de dict {numero, titre, texte}. La table des matières
    (où les numéros sont suivis du titre sur la même ligne) est ignorée.
    """
    marques = list(_CHIFFRE_ROMAIN.finditer(roman))
    chapitres = []
    for i, m in enumerate(marques):
        fin = marques[i + 1].start() if i + 1 < len(marques) else len(roman)
        chapitres.append({"numero": m.group(1), "titre": m.group(2).strip(),
                          "texte": roman[m.end():fin].strip()})
    return chapitres


def lignes_contenant(roman: str, mot: str, n: int = 5) -> list[str]:
    mot = mot.lower()
    return [l.strip() for l in roman.split("\n") if mot in l.lower()][:n]
