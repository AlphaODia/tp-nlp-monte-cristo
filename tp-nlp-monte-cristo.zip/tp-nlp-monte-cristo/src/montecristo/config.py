"""Constantes du projet : chemins, sources du corpus, paramètres par défaut."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
DATA_DIR = ROOT / "data"
FIG_DIR = ROOT / "figures"
OUT_DIR = ROOT / "outputs"
REPORT_DIR = ROOT / "rapport"

GUTENBERG_ID = 17989
SOURCES = [
    f"https://www.gutenberg.org/files/{GUTENBERG_ID}/{GUTENBERG_ID}-0.txt",
    f"https://www.gutenberg.org/cache/epub/{GUTENBERG_ID}/pg{GUTENBERG_ID}.txt",
]
RAW_FILE = DATA_DIR / f"{GUTENBERG_ID}-0.txt"
NOVEL_FILE = DATA_DIR / "monte_cristo.txt"

SPACY_MODEL = "fr_core_news_sm"

# Lettres conservées par le nettoyage (alphabet français)
LETTRES_FR = "a-zàâçéèêëîïôûùüÿñæœ"

# Stop words ajoutés pour ce roman (Partie 6 du sujet)
STOPWORDS_ROMAN = {
    "dit", "disant", "répondit", "reprit", "ajouta", "cria",
    "monsieur", "madame", "mademoiselle", "car", "alors", "puis",
    "bien", "encore", "tout", "très", "plus", "non", "oui", "si",
}

PERSONNAGES = ["dantès", "danglars", "fernand", "villefort", "faria", "mercédès",
               "caderousse", "morrel"]

TAILLE_BLOC = 2000
NB_BLOCS = 20
