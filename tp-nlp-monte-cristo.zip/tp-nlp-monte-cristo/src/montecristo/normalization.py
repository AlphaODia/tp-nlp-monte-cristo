"""Stemming (Partie 8) et lemmatisation avec SpaCy (Partie 9)."""
from collections import Counter, defaultdict

import pandas as pd
from nltk.stem import SnowballStemmer

_stemmer = SnowballStemmer("french")


def charger_spacy(modele: str = "fr_core_news_sm"):
    import spacy
    nlp = spacy.load(modele)
    nlp.max_length = 2_000_000
    return nlp


def stem(mot: str) -> str:
    return _stemmer.stem(mot)


def familles(tokens: list[str]) -> dict[str, set]:
    """Regroupe les mots par racine commune."""
    groupes = defaultdict(set)
    for mot in set(tokens):
        groupes[stem(mot)].add(mot)
    return groupes


def frequence_prefixes(freq_racines: Counter, prefixes: list[str]) -> dict[str, int]:
    return {p: sum(n for r, n in freq_racines.items() if r.startswith(p)) for p in prefixes}


def analyse_spacy(doc) -> pd.DataFrame:
    return pd.DataFrame([{"token": t.text, "lemme": t.lemma_, "POS": t.pos_,
                          "est_stop": t.is_stop, "est_ponc": t.is_punct}
                         for t in doc if not t.is_space])


def lemmes_utiles(doc) -> list[str]:
    return [t.lemma_.lower() for t in doc
            if not (t.is_stop or t.is_punct or t.is_space) and len(t.text) > 2]


def noms_propres(nlp, texte: str, taille_morceau: int = 100_000) -> Counter:
    """Compte les PROPN sur le texte BRUT (les majuscules sont nécessaires)."""
    c = Counter()
    morceaux = [texte[i:i + taille_morceau] for i in range(0, len(texte), taille_morceau)]
    for d in nlp.pipe(morceaux, disable=["lemmatizer"]):
        c.update(t.text for t in d if t.pos_ == "PROPN" and len(t.text) > 2)
    return c


def comparer_stem_lemme(nlp, mots: list[str]) -> pd.DataFrame:
    return pd.DataFrame({"mot": mots,
                         "stemming": [stem(m) for m in mots],
                         "lemme": [nlp(m)[0].lemma_ for m in mots]})
