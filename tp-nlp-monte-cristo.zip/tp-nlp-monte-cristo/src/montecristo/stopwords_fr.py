"""Listes de stop words et filtrage (Partie 6)."""
from nltk.corpus import stopwords

from .config import STOPWORDS_ROMAN

ELISIONS = {"l'", "d'", "j'", "m'", "n'", "s'", "t'", "c'", "qu'", "jusqu'", "lorsqu'", "puisqu'"}


def listes_stopwords(nlp) -> tuple[set, set]:
    return set(stopwords.words("french")), set(nlp.Defaults.stop_words)


def stopwords_personnalises(nlp, avec_elisions: bool = False) -> set:
    """Union NLTK | SpaCy | mots propres au roman.

    (Dans le sujet l'union est écrite avec « │ » : l'opérateur Python est « | ».)
    """
    sw_nltk, sw_spacy = listes_stopwords(nlp)
    sw = sw_nltk | sw_spacy | STOPWORDS_ROMAN
    return sw | ELISIONS if avec_elisions else sw


def filtrer(tokens: list[str], stop: set, min_len: int = 3) -> list[str]:
    return [t for t in tokens if t.lower() not in stop and len(t) >= min_len]
