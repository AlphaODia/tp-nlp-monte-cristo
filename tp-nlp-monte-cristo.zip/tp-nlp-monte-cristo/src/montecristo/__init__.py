"""Pipeline NLP du TP 1 — Le Comte de Monte-Cristo (Tome I)."""
from . import config, corpus, cleaning, tokenization, stopwords_fr, normalization, frequencies, vectorization, plots

__all__ = ["config", "corpus", "cleaning", "tokenization", "stopwords_fr",
           "normalization", "frequencies", "vectorization", "plots"]
__version__ = "1.0.0"
