"""Analyse fréquentielle : top N, loi de Zipf, rangs, hapax, personnages (Parties 5-6)."""
from collections import Counter

import numpy as np
import pandas as pd


def table_top(freq: Counter, total: int, n: int = 20) -> pd.DataFrame:
    rows = [{"rang": i, "mot": m, "frequence": c, "pct": c / total * 100}
            for i, (m, c) in enumerate(freq.most_common(n), 1)]
    return pd.DataFrame(rows)


def pente_zipf(freq: Counter, rang_min: int = 10, rang_max: int = 5000) -> float:
    """Pente de la régression log(fréquence) ~ log(rang). Zipf idéal : -1."""
    f = np.array(sorted(freq.values(), reverse=True), dtype=float)
    r = np.arange(1, len(f) + 1)
    sl = slice(rang_min - 1, min(rang_max, len(f)))
    return float(np.polyfit(np.log(r[sl]), np.log(f[sl]), 1)[0])


def rangs(freq: Counter, mots: list[str]) -> pd.DataFrame:
    classement = {m: i for i, (m, _) in enumerate(freq.most_common(), 1)}
    return pd.DataFrame([{"mot": m, "frequence": freq[m], "rang": classement.get(m)} for m in mots])


def hapax(freq: Counter) -> list[str]:
    return [m for m, c in freq.items() if c == 1]


def presence_par_chapitre(chapitres: list[dict], noms: list[str], nettoyer) -> pd.DataFrame:
    """Occurrences de chaque personnage par chapitre (pour suivre l'intrigue)."""
    data = {}
    for ch in chapitres:
        mots = nettoyer(ch["texte"]).split()
        data[ch["numero"]] = {n: mots.count(n) for n in noms}
    return pd.DataFrame(data)
