"""Matrice Document-Terme, BoW, TF-IDF, similarité et recherche (Parties 10-11)."""
import pandas as pd
from sklearn.feature_extraction.text import CountVectorizer, TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

from .config import TAILLE_BLOC, NB_BLOCS

PARAMS = dict(lowercase=True, min_df=2, max_df=0.90, max_features=300)


def blocs_de_mots(texte_propre: str, taille: int = TAILLE_BLOC, nb: int | None = NB_BLOCS):
    """Découpe en blocs de `taille` mots. nb=None garde tout le texte.

    Le sujet limite à 20 blocs (40 000 mots, ~1/3 du tome).
    """
    mots = texte_propre.split()
    limite = len(mots) if nb is None else min(len(mots), taille * nb)
    blocs = [" ".join(mots[i:i + taille]) for i in range(0, limite, taille)]
    return blocs, [f"Bloc_{i + 1:02d}" for i in range(len(blocs))]


def matrice_bow(blocs, noms, stop_words):
    vec = CountVectorizer(stop_words=list(stop_words), **PARAMS)
    X = vec.fit_transform(blocs)
    return vec, X, pd.DataFrame(X.toarray(), index=noms, columns=vec.get_feature_names_out())


def matrice_tfidf(blocs, noms, stop_words):
    vec = TfidfVectorizer(stop_words=list(stop_words), sublinear_tf=True,
                          use_idf=True, smooth_idf=True, **PARAMS)
    X = vec.fit_transform(blocs)
    return vec, X, pd.DataFrame(X.toarray().round(4), index=noms, columns=vec.get_feature_names_out())


def densite(df: pd.DataFrame) -> float:
    return float((df > 0).to_numpy().mean() * 100)


def mots_signatures(df: pd.DataFrame, n: int = 5) -> pd.DataFrame:
    out = pd.DataFrame({b: list(df.loc[b].sort_values(ascending=False).head(n).index)
                        for b in df.index}).T
    out.columns = [f"mot_{i + 1}" for i in range(n)]
    return out


def similarites(X, noms) -> pd.DataFrame:
    return pd.DataFrame(cosine_similarity(X).round(3), index=noms, columns=noms)


def paires_extremes(sim: pd.DataFrame, n: int = 5):
    noms = list(sim.index)
    paires = [(a, b, float(sim.loc[a, b])) for i, a in enumerate(noms) for b in noms[i + 1:]]
    paires.sort(key=lambda x: -x[2])
    return paires[:n], paires[-n:][::-1]


class MoteurRecherche:
    """Mini-moteur TF-IDF : classe les blocs par similarité cosinus avec la requête."""

    def __init__(self, vectoriseur, X, noms):
        self.vec, self.X, self.noms = vectoriseur, X, noms

    def termes_connus(self, requete: str) -> list[str]:
        return [m for m in requete.lower().split() if m in self.vec.vocabulary_]

    def chercher(self, requete: str, k: int = 3):
        scores = cosine_similarity(self.vec.transform([requete]), self.X)[0]
        return sorted(((nom, round(float(s), 3)) for nom, s in zip(self.noms, scores)), key=lambda x: -x[1])[:k]
