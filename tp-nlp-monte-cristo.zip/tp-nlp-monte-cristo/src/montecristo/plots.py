"""Graphiques du TP. Chaque fonction renvoie la figure et peut l'enregistrer dans figures/."""
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import seaborn as sns
from wordcloud import WordCloud

from .config import FIG_DIR


def _sauver(fig, nom: str | None):
    if nom:
        FIG_DIR.mkdir(exist_ok=True)
        fig.savefig(FIG_DIR / nom, dpi=110, bbox_inches="tight")
    return fig


def barres_top(top, titre, nom=None):
    mots, vals = [m for m, _ in top][::-1], [n for _, n in top][::-1]
    fig, ax = plt.subplots(figsize=(11, 6))
    bars = ax.barh(mots, vals, color="steelblue")
    for b, v in zip(bars, vals):
        ax.text(b.get_width() * 1.01, b.get_y() + b.get_height() / 2, str(v), va="center", fontsize=9)
    ax.set_xlabel("Fréquence"); ax.set_title(titre)
    fig.tight_layout()
    return _sauver(fig, nom)


def zipf(freq, pente, nom=None):
    f = np.array(sorted(freq.values(), reverse=True)); r = np.arange(1, len(f) + 1)
    fig, ax = plt.subplots(figsize=(9, 5))
    ax.loglog(r, f, ".", ms=2, alpha=.5, label="Corpus")
    ax.loglog(r, f[0] / r, "--", color="crimson", lw=1, label="Zipf théorique C/r")
    ax.set(xlabel="Rang (log)", ylabel="Fréquence (log)",
           title=f"Loi de Zipf — pente estimée {pente:.2f}")
    ax.legend(); ax.grid(True, which="both", alpha=.3); fig.tight_layout()
    return _sauver(fig, nom)


def nuage(texte_ou_freq, titre="", nom=None, ax=None, **kw):
    params = dict(width=1000, height=500, background_color="white", colormap="Blues",
                  collocations=False, max_words=150)
    params.update(kw)
    wc = WordCloud(**params)
    wc = wc.generate_from_frequencies(texte_ou_freq) if isinstance(texte_ou_freq, dict) \
        else wc.generate(texte_ou_freq)
    if ax is None:
        fig, ax = plt.subplots(figsize=(14, 7))
    else:
        fig = ax.figure
    ax.imshow(wc, interpolation="bilinear"); ax.axis("off"); ax.set_title(titre)
    if nom:
        _sauver(fig, nom)
    return wc


def heatmap(df, titre, nom=None, cmap="YlOrRd", annot=False, figsize=(13, 7)):
    fig, ax = plt.subplots(figsize=figsize)
    sns.heatmap(df, cmap=cmap, linewidths=.3, annot=annot, fmt="d" if annot else ".2g", ax=ax)
    ax.set_title(titre); fig.tight_layout()
    return _sauver(fig, nom)


def repartition_pos(pos_counts, nom=None):
    labels, vals = zip(*pos_counts.most_common())
    fig, ax = plt.subplots(figsize=(10, 4.5))
    ax.bar(labels, vals, color="slategray"); ax.set_ylabel("Tokens")
    ax.set_title("Catégories grammaticales — chapitre I (SpaCy)"); fig.tight_layout()
    return _sauver(fig, nom)
