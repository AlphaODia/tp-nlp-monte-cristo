"""Tokenisation en mots et en phrases, n-grammes, comparaison NLTK / SpaCy (Partie 4)."""
from collections import Counter

import pandas as pd
from nltk import bigrams
from nltk.tokenize import sent_tokenize, word_tokenize


def tokeniser(texte: str) -> list[str]:
    return word_tokenize(texte, language="french")


def phrases(texte_brut: str) -> list[str]:
    """Segmentation en phrases — à appliquer au texte NON nettoyé.

    Sur le texte nettoyé (sans points), NLTK ne trouve qu'une seule phrase.
    """
    return sent_tokenize(texte_brut, language="french")


def stats_vocabulaire(tokens: list[str]) -> dict:
    v = len(set(tokens))
    return {"tokens": len(tokens), "vocabulaire": v, "richesse": v / len(tokens)}


def top_bigrammes(tokens: list[str], n: int = 20, exclure: set | None = None, min_len: int = 3):
    """Bigrammes les plus fréquents ; `exclure` filtre les stop words."""
    if exclure is None:
        return Counter(bigrams(tokens)).most_common(n)
    return Counter((a, b) for a, b in bigrams(tokens)
                   if a not in exclure and b not in exclure
                   and len(a) >= min_len and len(b) >= min_len).most_common(n)


def comparer_nltk_spacy(texte: str, nlp) -> dict:
    t_nltk = tokeniser(texte)
    t_spacy = [t.text for t in nlp(texte) if not t.is_space]
    return {
        "nltk": t_nltk, "spacy": t_spacy,
        "propres_nltk": sorted(set(t_nltk) - set(t_spacy)),
        "propres_spacy": sorted(set(t_spacy) - set(t_nltk)),
    }


def dataframe_tokens(tokens: list[str]) -> pd.DataFrame:
    df = pd.DataFrame({"position": range(len(tokens)), "token": tokens})
    df["longueur"] = df["token"].str.len()
    return df
