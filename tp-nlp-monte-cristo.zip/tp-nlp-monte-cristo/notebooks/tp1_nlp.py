# %% [markdown]
# # TP 1 NLP — *Le Comte de Monte-Cristo* (Tome I)
# **Master 2 IA — Prétraitement, représentation et analyse de textes**
#
# Ce notebook présente les résultats. Toute la logique est dans le package `src/montecristo/`
# (chargement, nettoyage, tokenisation, normalisation, fréquences, vectorisation, graphiques).
# Les figures sont enregistrées dans `figures/`, les tableaux dans `outputs/`.

# %%
import sys
from pathlib import Path
RACINE = Path.cwd() if (Path.cwd() / 'src').exists() else Path.cwd().parent
sys.path.insert(0, str(RACINE / 'src'))

import re
from collections import Counter
import pandas as pd
import matplotlib.pyplot as plt
import nltk, spacy, sklearn

from montecristo import (config, corpus, cleaning, tokenization as tok, stopwords_fr as swf,
                         normalization as norm, frequencies as fq, vectorization as vz, plots)

for res in ['punkt', 'punkt_tab', 'stopwords']:
    nltk.download(res, quiet=True)
config.OUT_DIR.mkdir(exist_ok=True)
pd.set_option('display.width', 160)

# %% [markdown]
# ## Partie 1 — Installation et configuration

# %%
print('nltk', nltk.__version__, '| spacy', spacy.__version__,
      '| sklearn', sklearn.__version__, '| pandas', pd.__version__)
nlp = norm.charger_spacy(config.SPACY_MODEL)
print([(t.text, t.pos_) for t in nlp("Edmond Dantès fut injustement emprisonné au château d'If.")])

# %% [markdown]
# ## Partie 2 — Chargement du corpus

# %%
brut, origine = corpus.charger_texte_brut()
roman = corpus.extraire_roman(brut)
corpus.sauvegarder_roman(roman)
chapitres = corpus.decouper_chapitres(roman)

print(f'Source : {origine} | taille brute : {len(brut):,} caractères')
print(f'Roman  : {len(roman):,} caractères | {roman.count(chr(10)):,} lignes | {len(chapitres)} chapitres')
print(f'Mots (split) : {len(roman.split()):,} | pages estimées : {len(roman.split())/300:.0f}')
print(f"Occurrences de 'dantès' : {roman.lower().count('dantès')}")
print('--- 500 premiers caractères ---', roman[:500], sep='\n')
print('--- 200 derniers caractères ---', roman[-200:], sep='\n')

# %%
print("Lignes contenant 'vengeance' :")
for l in corpus.lignes_contenant(roman, 'vengeance', 5):
    print('  -', l)
print('\nChapitres :', [f"{c['numero']}. {c['titre']}" for c in chapitres[:6]], '…')

# %% [markdown]
# ## Partie 3 — Nettoyage

# %%
roman_clean = cleaning.clean_text(roman)
print(f'{len(roman):,} -> {len(roman_clean):,} caractères ({(1-len(roman_clean)/len(roman))*100:.1f}% de réduction)')
bruit = "«Ah! c'est vous, Dantès!» cria l'homme... (numéro 34)\n\n-- Il est mort!!"
print('b)', repr(cleaning.clean_text(bruit)))
print('c)', cleaning.clean_text('Le comte de Monte-Cristo'), '|',
      cleaning.clean_text('Le comte de Monte-Cristo', garder_tirets=True))
print('e) léger   :', cleaning.clean_text_leger(roman[2800:2950]))
print('e) complet :', cleaning.clean_text(roman[2800:2950]))

# %% [markdown]
# ## Partie 4 — Tokenisation

# %%
tokens = tok.tokeniser(roman_clean)
print(tok.stats_vocabulaire(tokens))
print(tokens[:50])

cmp = tok.comparer_nltk_spacy(roman_clean[:5000], nlp)
print(f"\nNLTK {len(cmp['nltk'])} tokens | SpaCy {len(cmp['spacy'])} tokens")
print('Propres à NLTK  :', cmp['propres_nltk'][:10])
print('Propres à SpaCy :', cmp['propres_spacy'][:10])

# %%
print('Phrases (20 000 car.) — texte brut :', len(tok.phrases(roman[:20000])),
      '| texte nettoyé :', len(tok.phrases(roman_clean[:20000])))
sw_nltk, sw_spacy = swf.listes_stopwords(nlp)
print('\nBigrammes bruts :', tok.top_bigrammes(tokens, 20))
print('\nBigrammes sans stop words :', tok.top_bigrammes(tokens, 20, exclure=sw_nltk))
df_tok = tok.dataframe_tokens(tokens)
print(f"\nLongueur moyenne des tokens : {df_tok['longueur'].mean():.2f}")

# %% [markdown]
# ## Partie 5 — Analyse fréquentielle

# %%
freq = Counter(tokens)
top = fq.table_top(freq, len(tokens), 20)
top.to_csv(config.OUT_DIR / 'top20_frequences.csv', index=False)
print(top.to_string(index=False))
plots.barres_top(freq.most_common(20), 'Top 20 des mots — Monte-Cristo, Tome I', '05_top20.png'); plt.show()

# %%
pente = fq.pente_zipf(freq)
plots.zipf(freq, pente, '05_zipf.png'); plt.show()
print(f'Pente log-log : {pente:.2f}')
print(fq.rangs(freq, ['dantès', 'vengeance', 'liberté', 'prison']).to_string(index=False))
hx = fq.hapax(freq)
print(f'Hapax : {len(hx):,} ({len(hx)/len(freq)*100:.1f}% du vocabulaire)')

# %% [markdown]
# ## Partie 6 — Stop words

# %%
print(f'NLTK {len(sw_nltk)} | SpaCy {len(sw_spacy)} | communs {len(sw_nltk & sw_spacy)}')
sw_custom = swf.stopwords_personnalises(nlp)
tokens_no_stop = swf.filtrer(tokens, sw_custom)
freq_clean = Counter(tokens_no_stop)
print(f'{len(tokens):,} -> {len(tokens_no_stop):,} tokens ({(1-len(tokens_no_stop)/len(tokens))*100:.1f}% supprimés)')
print('Top 20 :', freq_clean.most_common(20))
print({m: freq[m] for m in ['dit', 'répondit', 'monsieur']})
print(pd.Series({p: freq_clean[p] for p in config.PERSONNAGES}).sort_values(ascending=False).to_dict())

# %%
# Amélioration : séparer les élisions pour éliminer « qu'il », « c'est », « d'un »…
tokens_v2 = swf.filtrer(tok.tokeniser(cleaning.separer_elisions(roman_clean)),
                        swf.stopwords_personnalises(nlp, avec_elisions=True))
print('Top 20 avec élisions séparées :', Counter(tokens_v2).most_common(20))

# %% [markdown]
# ## Partie 7 — WordClouds

# %%
texte_clean = ' '.join(tokens_no_stop)
wc = plots.nuage(texte_clean, 'WordCloud — Tome I', '07_wordcloud_roman.png'); plt.show()
print('5 mots les plus visibles :', list(wc.words_)[:5])

# %%
phrases_roman = tok.phrases(roman)
fig, axes = plt.subplots(1, 3, figsize=(18, 5))
for ax, perso, cmap in zip(axes, ['dantès', 'danglars', 'villefort'], ['Blues', 'Reds', 'Greens']):
    texte_p = ' '.join(cleaning.clean_text(p) for p in phrases_roman if perso in p.lower())
    toks = [t for t in swf.filtrer(tok.tokeniser(texte_p), sw_custom, 4) if t != perso]
    plots.nuage(' '.join(toks), perso.capitalize(), ax=ax, colormap=cmap, width=500, height=350)
    print(f'{perso:<10}', [m for m, _ in Counter(toks).most_common(10)])
fig.savefig(config.FIG_DIR / '07_wordcloud_personnages.png', dpi=110, bbox_inches='tight'); plt.show()

# %%
propn = norm.noms_propres(nlp, roman)
pd.DataFrame(propn.most_common(40), columns=['nom_propre', 'frequence']).to_csv(config.OUT_DIR / 'noms_propres.csv', index=False)
print(propn.most_common(25))
plots.nuage(dict(propn), 'Noms propres (PROPN, SpaCy)', '07_wordcloud_noms_propres.png', colormap='RdYlGn'); plt.show()

# %%
fig, axes = plt.subplots(1, 2, figsize=(18, 6))
for ax, mw in zip(axes, [50, 200]):
    plots.nuage(texte_clean, f'max_words={mw}', ax=ax, colormap='RdYlGn', max_words=mw, width=800, height=450)
fig.savefig(config.FIG_DIR / '07_wordcloud_max_words.png', dpi=110, bbox_inches='tight'); plt.show()

fig, axes = plt.subplots(1, 2, figsize=(18, 6))
for ax, part, titre in zip(axes, [tokens_no_stop[:3000], tokens_no_stop[-3000:]], ['3000 premiers mots', '3000 derniers mots']):
    plots.nuage(' '.join(part), titre, ax=ax, width=800, height=450)
    print(titre, ':', [m for m, _ in Counter(part).most_common(12)])
fig.savefig(config.FIG_DIR / '07_wordcloud_debut_fin.png', dpi=110, bbox_inches='tight'); plt.show()

# %%
# Suivi des personnages chapitre par chapitre (analyse complémentaire)
presence = fq.presence_par_chapitre(chapitres, ['dantès', 'edmond', 'morrel', 'danglars', 'fernand',
                                                'mercédès', 'villefort', 'faria', 'franz'], cleaning.clean_text)
presence.to_csv(config.OUT_DIR / 'personnages_par_chapitre.csv')
plots.heatmap(presence, 'Occurrences des personnages par chapitre', '07_personnages_chapitres.png',
              cmap='Blues', annot=True, figsize=(16, 5)); plt.show()

# %% [markdown]
# ## Partie 8 — Stemming

# %%
mots_test = ['dantès', 'vengeance', 'venger', 'vengeur', 'vindicatif', 'prison', 'prisonnier',
             'emprisonner', 'emprisonnement', 'liberté', 'libérer', 'libérateur', 'libération',
             'mer', 'marin', 'maritime', 'navire', 'naviguer']
print({m: norm.stem(m) for m in mots_test})
tokens_stem = [norm.stem(t) for t in tokens_no_stop]
freq_stem = Counter(tokens_stem)
v1, v2 = len(set(tokens_no_stop)), len(set(tokens_stem))
print(f'Vocabulaire : {v1:,} -> {v2:,} racines ({(1-v2/v1)*100:.1f}% de réduction)')
fams = norm.familles(tokens_no_stop)
for r, ms in sorted(fams.items(), key=lambda x: -len(x[1]))[:8]:
    print(f'[{r}] {len(ms)} formes : {sorted(ms)[:6]}')
print('Faux amis :', {m: norm.stem(m) for m in ['port', 'portait', 'sort', 'sortait', 'mont', 'montait']})
print('Racines :', norm.frequence_prefixes(freq_stem, ['veng', 'pris', 'liber', 'dant']))

# %% [markdown]
# ## Partie 9 — Lemmatisation (SpaCy)

# %%
ch1 = chapitres[0]
doc = nlp(ch1['texte'].replace('_', ''))  # retire les marqueurs d'italique _Pharaon_
df_ch1 = norm.analyse_spacy(doc)
df_ch1.to_csv(config.OUT_DIR / 'chapitre1_spacy.csv', index=False)
print(f"Chapitre {ch1['numero']} « {ch1['titre']} » : {len(df_ch1):,} tokens")
print(df_ch1.head(20).to_string(index=False))

# %%
print('Top lemmes :', Counter(norm.lemmes_utiles(doc)).most_common(15))
print('NOUN :', Counter(t.lemma_.lower() for t in doc if t.pos_ == 'NOUN').most_common(15))
print('PROPN :', Counter(t.text for t in doc if t.pos_ == 'PROPN').most_common(15))
pos = Counter(t.pos_ for t in doc if not t.is_space)
plots.repartition_pos(pos, '09_pos_chapitre1.png'); plt.show()

# %%
cmp_sl = norm.comparer_stem_lemme(nlp, ['navire', 'prisonnier', 'vengeance', 'chevaux', 'yeux', 'allaient',
                                        'fut', 'meilleurs', 'emprisonné', 'libérés', 'heureux', 'faisait',
                                        'jeunesse', 'pouvait', 'mers'])
cmp_sl.to_csv(config.OUT_DIR / 'stemming_vs_lemmatisation.csv', index=False)
print(cmp_sl.to_string(index=False))
for p in ["L'oiseau vole au-dessus de la mer.", "Le vol a été commis hier.", "Il vole de l'argent."]:
    print(p, [(t.text, t.pos_, t.lemma_) for t in nlp(p) if t.text.lower().startswith('vol')])

# %% [markdown]
# ## Partie 10 — Matrice Document-Terme & BoW

# %%
blocs, noms_blocs = vz.blocs_de_mots(roman_clean)
vec_bow, X_bow, bow_df = vz.matrice_bow(blocs, noms_blocs, sw_custom)
print(f'{X_bow.shape[0]} documents x {X_bow.shape[1]} mots — densité {vz.densite(bow_df):.1f}%')
print(bow_df.sum().sort_values(ascending=False).head(10).to_dict())
pers_blocs = pd.DataFrame({p: [b.split().count(p) for b in blocs] for p in
                           ['dantès', 'danglars', 'faria', 'villefort', 'mercédès', 'fernand']}, index=noms_blocs)
print(pers_blocs.T.to_string())
print('Bloc max :', pers_blocs.idxmax()[pers_blocs.max() > 0].to_dict())
print("1re occurrence de 'faria' : mot n°", roman_clean.split().index('faria'))

# %%
top15 = bow_df.sum().sort_values(ascending=False).head(15).index
plots.heatmap(bow_df[top15], 'Matrice BoW — 15 mots les plus fréquents', '10_heatmap_bow.png'); plt.show()
from sklearn.feature_extraction.text import CountVectorizer
Xf = CountVectorizer(stop_words=list(sw_custom)).fit_transform(blocs)
print(f'Zéros : {100-vz.densite(bow_df):.1f}% (300 termes) | {(1-Xf.nnz/(Xf.shape[0]*Xf.shape[1]))*100:.1f}% (vocabulaire complet {Xf.shape[1]})')

# %% [markdown]
# ## Partie 11 — TF-IDF & comparaison

# %%
vec_tfidf, X_tfidf, tfidf_df = vz.matrice_tfidf(blocs, noms_blocs, sw_custom)
sig = vz.mots_signatures(tfidf_df, 5)
sig.to_csv(config.OUT_DIR / 'tfidf_signatures_blocs.csv')
print(sig.to_string())

# %%
sim = vz.similarites(X_tfidf, noms_blocs)
plots.heatmap(sim, 'Similarité cosinus entre blocs (TF-IDF)', '11_similarite_cosinus.png', cmap='Blues', figsize=(11, 9)); plt.show()
proches, eloignes = vz.paires_extremes(sim)
print('Plus proches :', proches)
print('Plus éloignés :', eloignes)

# %%
moteur = vz.MoteurRecherche(vec_tfidf, X_tfidf, noms_blocs)
requete = 'château if prison dantès'
print('Termes connus :', moteur.termes_connus(requete))
print('Résultats :', moteur.chercher(requete))
print('BoW    Bloc_01 :', list(bow_df.loc['Bloc_01'].sort_values(ascending=False).head(10).index))
print('TF-IDF Bloc_01 :', list(tfidf_df.loc['Bloc_01'].sort_values(ascending=False).head(10).index))
for m in ['dantès', 'danglars']:
    print(m, 'BoW', bow_df.loc['Bloc_01', m], '| TF-IDF', tfidf_df.loc['Bloc_01', m],
          '| IDF', round(vec_tfidf.idf_[vec_tfidf.vocabulary_[m]], 3))

# %%
recap = pd.DataFrame([
    ('Caractères (roman)', len(roman)), ('Mots (split)', len(roman.split())), ('Chapitres', len(chapitres)),
    ('Tokens NLTK', len(tokens)), ('Vocabulaire', len(set(tokens))),
    ('Pente de Zipf', round(pente, 2)), ('Hapax (% vocabulaire)', round(len(hx)/len(freq)*100, 1)),
    ('Tokens supprimés par stop words (%)', round((1-len(tokens_no_stop)/len(tokens))*100, 1)),
    ('Réduction du vocabulaire par stemming (%)', round((1-v2/v1)*100, 1)),
    ('Zéros matrice BoW (%)', round(100-vz.densite(bow_df), 1)),
    ('Meilleur bloc pour « château if prison dantès »', moteur.chercher(requete)[0][0]),
], columns=['indicateur', 'valeur'])
recap.to_csv(config.OUT_DIR / 'recapitulatif.csv', index=False)
print(recap.to_string(index=False))
