"""Remplit le sujet Word (docs/sujet_TP1_NLP.docx) avec les réponses et les figures.

Usage : python scripts/build_report.py
Sortie : rapport/TP1_NLP_Master2_IA_Reponses.docx
Les réponses sont dans scripts/reponses.py ; les figures viennent de figures/
(lancer d'abord scripts/build_notebook.py ou le notebook).

Mini-syntaxe des réponses : '## ' titre, '- ' puce, 'IMG:fichier.png', 'CODE:ligne',
('TAB', lignes) tableau, **gras** en ligne.
"""
import re
import sys
from pathlib import Path

from docx import Document
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches, Pt, RGBColor

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(Path(__file__).parent))
from reponses import A, EVAL  # noqa: E402

SUJET = ROOT / "docs" / "sujet_TP1_NLP.docx"
SORTIE = ROOT / "rapport" / "TP1_NLP_Master2_IA_Reponses.docx"
FIGURES = ROOT / "figures"
TEXTE = RGBColor(0x1F, 0x2A, 0x37)
TITRE = RGBColor(0x1F, 0x4E, 0x79)
LARGEUR_TABLE = 8900  # en DXA, tient dans la case réponse (9200)


def espacement(p, apres=2.0, avant=0.0):
    p.paragraph_format.space_after = Pt(apres)
    p.paragraph_format.space_before = Pt(avant)


def ecrire(p, texte, taille=10, couleur=TEXTE, tout_gras=False, mono=False):
    police = "Consolas" if mono else "Calibri"
    for i, morceau in enumerate(re.split(r"\*\*", texte)):
        if not morceau:
            continue
        r = p.add_run(morceau)
        r.font.size, r.font.color.rgb = Pt(taille), couleur
        r.bold = tout_gras or i % 2 == 1
        rpr = r._r.get_or_add_rPr()
        polices = rpr.find(qn("w:rFonts"))
        if polices is None:
            polices = OxmlElement("w:rFonts")
            rpr.insert(0, polices)
        for attr in ("w:ascii", "w:hAnsi", "w:cs", "w:eastAsia"):
            polices.set(qn(attr), police)


def _fond(element_pr, couleur, avant=None):
    shd = OxmlElement("w:shd")
    shd.set(qn("w:val"), "clear"); shd.set(qn("w:color"), "auto"); shd.set(qn("w:fill"), couleur)
    ref = element_pr.find(qn(avant)) if avant else None
    ref.addprevious(shd) if ref is not None else element_pr.append(shd)


def _bordures(table):
    tbl_pr = table._tbl.tblPr
    b = OxmlElement("w:tblBorders")
    for cote in ("top", "left", "bottom", "right", "insideH", "insideV"):
        x = OxmlElement(f"w:{cote}")
        x.set(qn("w:val"), "single"); x.set(qn("w:sz"), "4"); x.set(qn("w:color"), "BFC9D4")
        b.append(x)
    ref = tbl_pr.find(qn("w:tblLayout"))
    if ref is None:  # (pas de « or » : un élément lxml sans enfant est « faux »)
        ref = tbl_pr.find(qn("w:tblLook"))
    ref.addprevious(b) if ref is not None else tbl_pr.append(b)


def tableau(cellule, lignes):
    ncol = len(lignes[0])
    t = cellule.add_table(rows=len(lignes), cols=ncol)
    t.autofit = False
    _bordures(t)
    poids = [max(min(max(len(str(l[j])) for l in lignes), 60), 8) for j in range(ncol)]
    largeurs = [int(LARGEUR_TABLE * p / sum(poids)) for p in poids]
    for col, w in zip(t._tbl.tblGrid.findall(qn("w:gridCol")), largeurs):
        col.set(qn("w:w"), str(w))
    tbl_w = t._tbl.tblPr.find(qn("w:tblW"))
    tbl_w.set(qn("w:w"), str(LARGEUR_TABLE)); tbl_w.set(qn("w:type"), "dxa")
    for i, ligne in enumerate(lignes):
        for j, val in enumerate(ligne):
            c = t.cell(i, j)
            c.width = Inches(largeurs[j] / 1440)
            espacement(c.paragraphs[0], 0)
            ecrire(c.paragraphs[0], val, 9, TITRE if i == 0 else TEXTE, tout_gras=i == 0)
            if i == 0:
                _fond(c._tc.get_or_add_tcPr(), "E8EEF5")


def remplir_case(cellule, elements):
    for p in cellule.paragraphs[1:]:          # on garde l'étiquette « Réponse : »
        p._p.getparent().remove(p._p)
    for el in elements:
        if isinstance(el, tuple):
            tableau(cellule, el[1])
            espacement(cellule.add_paragraph(), 1)
            continue
        p = cellule.add_paragraph()
        espacement(p, 2.5)
        if el.startswith("## "):
            espacement(p, 1.5, 6)
            ecrire(p, el[3:], 10.5, TITRE, tout_gras=True)
        elif el.startswith("- "):
            p.paragraph_format.left_indent = Inches(0.22)
            p.paragraph_format.first_line_indent = Inches(-0.14)
            ecrire(p, "– " + el[2:])
        elif el.startswith("IMG:"):
            p.add_run().add_picture(str(FIGURES / el[4:]), width=Inches(5.6))
        elif el.startswith("CODE:"):
            ecrire(p, el[5:], 8.5, RGBColor(0x33, 0x33, 0x33), mono=True)
            _fond(p._p.get_or_add_pPr(), "F3F4F6", avant="w:spacing")
        else:
            ecrire(p, el)


def main():
    doc = Document(SUJET)
    cases = [t.cell(0, 0) for t in doc.tables if t.cell(0, 0).text.strip().startswith("Réponse")]
    assert len(cases) == len(A), f"{len(cases)} cases dans le sujet, {len(A)} réponses"
    for case, elements in zip(cases, A):
        remplir_case(case, elements)

    synthese = next(t for t in doc.tables
                    if len(t.columns) == 4 and "Votre" in t.rows[0].cells[3].text)
    for ligne, texte in zip(synthese.rows[1:], EVAL):
        p = ligne.cells[3].paragraphs[0]
        for r in p.runs:
            r.text = ""
        ecrire(p, texte, 8.5)

    SORTIE.parent.mkdir(exist_ok=True)
    doc.save(SORTIE)
    print(f"Rapport écrit : {SORTIE}")


if __name__ == "__main__":
    main()
