"""Exécute notebooks/tp1_nlp.py cellule par cellule et écrit le notebook .ipynb avec ses sorties.

Usage : python scripts/build_notebook.py
(Équivalent sans Jupyter de : jupytext --to ipynb + jupyter nbconvert --execute)
"""
import base64, contextlib, io, json, os, sys, time, traceback
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "notebooks" / "tp1_nlp.py"
DEST = ROOT / "notebooks" / "TP1_NLP_Monte_Cristo.ipynb"


def main():
    os.chdir(ROOT / "notebooks")
    blocs = [c for c in SRC.read_text(encoding="utf-8").split("# %%") if c.strip()]
    ns, cells, n = {"__name__": "__main__"}, [], 0
    for bloc in blocs:
        if bloc.startswith(" [markdown]"):
            lignes = bloc[len(" [markdown]"):].strip("\n").split("\n")
            md = "\n".join(l[2:] if l.startswith("# ") else l.lstrip("#") for l in lignes)
            cells.append({"cell_type": "markdown", "metadata": {}, "source": md})
            continue
        code, images, out = bloc.strip("\n"), [], io.StringIO()

        def show(*_a, **_k):
            for num in plt.get_fignums():
                buf = io.BytesIO()
                plt.figure(num).savefig(buf, format="png", dpi=72, bbox_inches="tight")
                images.append(base64.b64encode(buf.getvalue()).decode())
            plt.close("all")
        plt.show = show
        n += 1; t0 = time.time()
        try:
            with contextlib.redirect_stdout(out):
                exec(compile(code, f"<cellule {n}>", "exec"), ns)
        except Exception:
            out.write(traceback.format_exc())
            print(f"ERREUR cellule {n}", file=sys.stderr)
        outputs = [{"output_type": "stream", "name": "stdout", "text": out.getvalue()}] if out.getvalue() else []
        outputs += [{"output_type": "display_data", "metadata": {},
                     "data": {"image/png": im, "text/plain": "<Figure>"}} for im in images]
        cells.append({"cell_type": "code", "metadata": {}, "execution_count": n,
                      "source": code, "outputs": outputs})
        print(f"cellule {n} ({time.time() - t0:.1f}s)", file=sys.stderr)

    for c in cells:
        c["source"] = c["source"].splitlines(keepends=True)
        c["id"] = os.urandom(4).hex()
    nb = {"nbformat": 4, "nbformat_minor": 5, "cells": cells,
          "metadata": {"kernelspec": {"name": "python3", "display_name": "Python 3", "language": "python"},
                       "language_info": {"name": "python", "version": sys.version.split()[0]}}}
    DEST.write_text(json.dumps(nb, ensure_ascii=False, indent=1), encoding="utf-8")
    print(f"Notebook écrit : {DEST}")


if __name__ == "__main__":
    main()
