# -*- coding: utf-8 -*-
"""Réponses du TP, dans l'ordre des 27 cases « Réponse : » du sujet.
Mini-syntaxe : '## ' = ligne-titre en gras ; '- ' = puce ; 'IMG:fichier' = figure ;
('TAB', [lignes]) = tableau ; **gras** en ligne ; 'CODE:' = ligne de code."""

A = []

# ---------------- PARTIE 1 : travail demandé
A.append([
 "## a) Installations",
 "Toutes les librairies s'importent sans erreur ; les ressources NLTK (punkt, punkt_tab, stopwords) et le modèle fr_core_news_sm sont chargés. Message obtenu : « Modèle SpaCy chargé avec succès ! ».",
 "## b) Versions",
 "CODE:nltk 3.10.4 | spacy 3.8.19 | sklearn 1.9.1 | pandas 3.0.5",
 "## c) Test du modèle SpaCy",
 "CODE:[('Edmond','PROPN'), ('Dantès','PROPN'), ('fut','AUX'), ('injustement','ADV'), ('emprisonné','VERB'), ('au','ADP'), ('château','NOUN'), (\"d'\",'ADP'), ('If','PROPN'), ('.','PUNCT')]",
 "Le modèle reconnaît correctement les deux noms propres, l'auxiliaire « fut » (être), le participe « emprisonné » (VERB) et sépare l'élision « d' ». Le modèle est opérationnel.",
])

# ---------------- PARTIE 2
A.append([
 "Remarque préalable : le fichier 17989 correspond au **Tome I** seulement (31 chapitres, de « Marseille. — L'arrivée » à « Italie. — Simbad le marin ») (le roman complet compte 4 tomes sur Gutenberg, n° 17989 à 17992). Selon la version du fichier, le marqueur est « *** START OF THE PROJECT… » ou « *** START OF THIS PROJECT… » ; j'ai utilisé une regex qui accepte les deux pour que split() ne plante pas.",
 "## a) Statistiques de base",
 ('TAB', [["Mesure", "Valeur"],
          ["Taille brute (avec en-tête Gutenberg)", "747 000 caractères"],
          ["Taille du roman (sans métadonnées)", "727 635 caractères"],
          ["Nombre de lignes", "16 710"],
          ["500 premiers caractères", "« Produced by Chuck Greif… LE COMTE DE MONTE-CRISTO, Tome I (1845-1846), Table des matières : I Marseille.--L'arrivée, II Le père et le fils, III Les Catalans… »"],
          ["200 derniers caractères", "« …sous les enchantements de ce rêve inouï. FIN DU TOME PREMIER — End of the Project Gutenberg EBook… »"]]),
 "## b) c) d) e)",
 "- b) Nombre de mots avec .split() : **121 600**.",
 "- c) roman.lower().count('dantès') = **777** occurrences.",
 "- d) 12 lignes contiennent « vengeance ». Les 5 premières : « que Fernand surtout était terrible dans sa vengeance » ; « À la bonne heure, continua Danglars; ainsi votre vengeance aurait le » ; « menaçant et fort pour toutes les vengeances; alors il manifesta à M. » ; « qui, pour lui aussi, était devenu messager d'une rude vengeance » ; « Il se disait que c'était la haine des hommes et non la vengeance de Dieu ».",
 "- e) 121 600 / 300 ≈ **405 pages** pour ce tome.",
])
A.append([
 "## Q1. Pourquoi supprimer les métadonnées ?",
 "L'en-tête et la licence Gutenberg (en anglais, ≈ 20 000 caractères ici) ne font pas partie de l'œuvre : ils ajouteraient des mots anglais (project, gutenberg, license, ebook…) qui fausseraient les fréquences, le vocabulaire, les stop words, et les représentations BoW/TF-IDF. On le voit d'ailleurs encore : la ligne de crédit « Produced by Chuck Greif and www.ebooksgratuits.com », située après le marqueur START, apparaît dans les premiers tokens (produced, by, chuck…) et dans les hapax.",
 "## Q2. .split() vs word_tokenize",
 ".split() découpe uniquement sur les espaces : la ponctuation reste collée aux mots (« Dantès! », « l'homme... ») et « Dantès » et « Dantès! » deviennent deux mots différents. word_tokenize applique des règles linguistiques (ponctuation séparée, élisions, abréviations). .split() suffit pour une estimation rapide ou sur un texte déjà nettoyé ; word_tokenize est préférable pour toute analyse fine.",
 "## Q3. Fréquence d'un nom = importance ?",
 "Partiellement seulement. Le héros est désigné par plusieurs noms (Dantès 777, Edmond 214, et plus tard « le comte », « Simbad le marin », « l'abbé Busoni ») : compter un seul nom sous-estime sa présence. À l'inverse, un personnage peut être central sans être souvent nommé (Faria : 105 occurrences, mais rôle décisif), et les pronoms « il / lui » ne sont pas comptés. Il faudrait regrouper les alias et résoudre les coréférences.",
])

# ---------------- PARTIE 3
A.append([
 "## a) Application",
 "Taille avant : 727 635 caractères → après : 695 557 caractères, soit **−4,4 %**. Aperçu : « produced by chuck greif and www ebooksgratuits com alexandre dumas le comte de monte cristo tome i table des matières… »",
 "## b) Extrait bruité",
 "CODE:\"ah c'est vous dantès cria l'homme numéro il est mort\"",
 "Il reste les mots en minuscules avec les apostrophes d'élision ; les guillemets « », les points d'exclamation, les points de suspension, les parenthèses, le nombre 34, les tirets et les sauts de ligne ont disparu.",
 "## c) Monte-Cristo",
 "Le tiret est remplacé par un espace : « monte-cristo » devient **« monte cristo »** (2 tokens). Solution : avant de supprimer la ponctuation, remplacer les tirets internes à un mot par un underscore et autoriser « _ » dans la regex :",
 "CODE:text = re.sub(r'(?<=[a-zà-ÿœæ])-(?=[a-zà-ÿœæ])', '_', text)   # -> monte_cristo",
 "Alternatives : MWETokenizer de NLTK avec [('monte','cristo')], ou un dictionnaire d'expressions figées.",
 "## d) Nombres isolés",
 "Ajout de text = re.sub(r'\\b\\d+\\b', ' ', text) avant la suppression de la ponctuation (option supprimer_nombres=True). « Le 24 février 1815 » devient « le février ».",
 "## e) clean_text_leger",
 "Version légère : 722 960 caractères contre 695 557. Elle garde la ponctuation, les marqueurs d'italique et les mots composés : « au-devant du _pharaon_, qu'il atteignit » au lieu de « au devant du pharaon qu'il atteignit ». Conséquence : des tokens parasites comme « _pharaon_ » et une ponctuation qui serait comptée comme des mots, mais en contrepartie la segmentation en phrases reste possible.",
 "**Bug repéré dans la fonction du sujet** : l'étape 5 (normalisation des apostrophes ’ → ') arrive après l'étape 4 qui supprime déjà tout caractère hors liste ; une apostrophe typographique serait donc effacée (« l’homme » → « l homme »). Il faut normaliser les apostrophes avant de filtrer, ce que fait ma version.",
])
A.append([
 "## Q1. Pourquoi nettoyer ? (3 raisons)",
 "- Réduire le bruit : ponctuation, chiffres, marqueurs typographiques ne portent pas le sens recherché.",
 "- Uniformiser : « Dantès », « dantès » et « Dantès! » doivent être un seul mot, sinon le vocabulaire est artificiellement gonflé.",
 "- Réduire la taille du vocabulaire et donc des matrices (BoW/TF-IDF), ce qui améliore les statistiques et la vitesse.",
 "## Q2. Problèmes sans nettoyage (exemples du roman)",
 "- Les marqueurs Gutenberg _Pharaon_ créent un mot « _pharaon_ » distinct de « pharaon ».",
 "- La casse sépare « Le » (début de phrase) et « le », « Dantès » et « DANTÈS ».",
 "- Les dates (1815, 24) et les tirets de dialogue « -- » apparaîtraient parmi les tokens fréquents.",
 "- Les sauts de ligne en milieu de phrase (texte coupé à 70 colonnes) coupent l'analyse.",
 "## Q3. Perte d'information ?",
 "Oui. La ponctuation sert à segmenter en phrases (après nettoyage, sent_tokenize ne trouve plus qu'**une seule phrase** dans les 20 000 premiers caractères contre 237 sur le texte brut), à repérer les dialogues (« » et --), les questions et exclamations (utile pour l'analyse de sentiment ou d'émotion), et la majuscule distingue les noms propres (utile pour la NER).",
 "## Q4. Toujours tout appliquer ?",
 "Non. Exemple : pour la reconnaissance d'entités nommées ou le POS tagging avec SpaCy, mettre en minuscules et supprimer la ponctuation dégrade fortement les résultats (le modèle s'appuie sur les majuscules et le contexte). Autre exemple : supprimer les nombres serait contre-productif pour extraire des dates (« 24 février 1815 ») ou des montants (« mille francs »).",
])

# ---------------- PARTIE 4
A.append([
 "## a) b) Tokenisation NLTK du roman",
 ('TAB', [["Mesure", "Valeur"],
          ["Nombre total de tokens", "123 589"],
          ["Tokens uniques (vocabulaire)", "11 973"],
          ["Richesse lexicale (unique / total)", "0,0969"]]),
 "50 premiers tokens : produced, by, chuck, greif, and, www, ebooksgratuits, com, alexandre, dumas, le, comte, de, monte, cristo, tome, i, table, des, matières, alexandre, dumas, i, marseille, l'arrivée, ii, le, père, et, le, fils, iii, les, catalans, iv, complot, v, le, repas, des, fiançailles, vi, le, substitut, du, procureur, du, roi, vii, l'interrogatoire. (On y voit la table des matières et les chiffres romains.)",
 "## c) NLTK vs SpaCy (5 000 premiers caractères)",
 ('TAB', [["Critère", "NLTK", "SpaCy"],
          ["Nombre de tokens", "877", "932"],
          ["Élisions", "gardées collées : « l'arrivée », « d'if », « c'est »", "séparées : « l' » + « arrivée », « c' » + « est »"],
          ["Chiffres romains, sigles", "tokens simples", "tokens simples"],
          ["Méthode", "expressions régulières", "règles + exceptions propres au français"],
          ["Vitesse", "très rapide", "plus lent (pipeline complet)"]]),
 "La différence de 55 tokens vient presque entièrement des élisions : SpaCy produit des unités plus proches des mots grammaticaux.",
 "## d) 20 bigrammes les plus fréquents",
 "Bruts : de la (589), à la (367), que je (222), que vous (186), de son (183), ce que (181), que le (174), je ne (174), je vous (165), à son (152), dit il (146), de sa (141), **jeune homme (140)**, dans le (135), **eh bien (135)**, et de (132), t il (129), dans la (129), et le (124), sur le (120).",
 "Ils sont dominés par des mots grammaticaux. Après avoir écarté les stop words, les bigrammes deviennent parlants : jeune homme (140), peut être (100), **dit caderousse (74)**, dit dantès (62), dit l'abbé (46), **louis xviii (45)**, **château d'if (43)**, **monte cristo (42)**, l'île d'elbe (36), monsieur morrel (35), mille francs (35). On retrouve les personnages, les lieux et le contexte historique (Louis XVIII, île d'Elbe, Napoléon). « dit il » et « t il » trahissent le style dialogué (« reprit-il », « dit-il »).",
 "## e) DataFrame des tokens",
 "Colonnes position, token, longueur (123 589 lignes). Longueur moyenne des tokens : **4,63 caractères**.",
])
A.append([
 "## Q1. Token vs mot",
 "Un token est l'unité produite par le découpage : mot, ponctuation, nombre, morceau de mot. Un mot est une unité linguistique. Ils ne coïncident pas toujours : « l'arrivée » est 1 token pour NLTK mais 2 mots (l' + arrivée) ; « monte-cristo » est 1 mot mais peut donner 2 ou 3 tokens ; « Dantès » peut devenir « dan ##tès » en sous-mots avec BERT.",
 "## Q2. Pourquoi fondamentale ?",
 "Toutes les étapes suivantes (fréquences, stop words, stemming, lemmatisation, BoW, TF-IDF, modèles neuronaux) travaillent sur des tokens. Une erreur de tokenisation se propage à toute la chaîne : c'est elle qui définit le vocabulaire.",
 "## Q3. NLTK = SpaCy ?",
 "Non (877 contre 932 tokens sur le même extrait). La principale différence est le traitement des élisions et des contractions françaises : SpaCy sépare « l' », « d' », « c' », « qu' » du mot suivant, NLTK les laisse collées. SpaCy produit aussi des attributs (is_stop, is_punct, POS) pour chaque token.",
 "## Q4. Quand préférer les bigrammes ?",
 "Lorsque le sens tient à l'association de deux mots : « château d'if » (lieu précis, alors que « château » seul est ambigu), « monte cristo », « jeune homme », « louis xviii ». Pour un moteur de recherche, une requête « château d'If » doit trouver les passages où les deux mots sont accolés, pas ceux qui parlent d'un château et, ailleurs, d'un if.",
])

# ---------------- PARTIE 5
A.append([
 "## a) Top 20",
 ('TAB', [["Rang", "Mot", "Fréq.", "%", "Rang", "Mot", "Fréq.", "%"],
          ["1", "de", "4841", "3,917", "11", "en", "1294", "1,047"],
          ["2", "le", "3210", "2,597", "12", "qui", "1279", "1,035"],
          ["3", "et", "3196", "2,586", "13", "je", "1278", "1,034"],
          ["4", "la", "2967", "2,401", "14", "ce", "1078", "0,872"],
          ["5", "à", "2762", "2,235", "15", "une", "958", "0,775"],
          ["6", "il", "2137", "1,729", "16", "dit", "938", "0,759"],
          ["7", "que", "1963", "1,588", "17", "son", "933", "0,755"],
          ["8", "vous", "1677", "1,357", "18", "pas", "929", "0,752"],
          ["9", "un", "1552", "1,256", "19", "ne", "926", "0,749"],
          ["10", "les", "1359", "1,100", "20", "dans", "917", "0,742"]]),
 "## b) Graphique en barres",
 "IMG:05_top20.png",
 "## c) Loi de Zipf",
 "IMG:05_zipf.png",
 "Le nuage de points forme approximativement une **droite** en échelle log-log : pente estimée **−1,14** (Zipf idéal : −1). La loi est donc globalement vérifiée. Écarts : en tête, les ratios ne suivent pas exactement 1/r (rang 2 : ratio 1,51 au lieu de 2 ; rang 5 : 1,75 au lieu de 5) ; en queue, les « marches » horizontales correspondent aux milliers de mots de fréquence 1, 2, 3…",
 "## d) Mots ciblés",
 ('TAB', [["Mot", "Fréquence", "Rang"],
          ["dantès", "777", "25"], ["prison", "67", "226"],
          ["liberté", "49", "307"], ["vengeance", "11", "1 146"]]),
 "Dantès est le premier mot « de contenu » du classement. « vengeance » est rare dans ce Tome I : le thème de la vengeance se développe surtout dans les tomes suivants.",
 "## e) Hapax legomena",
 "**6 055 mots** n'apparaissent qu'une fois, soit **50,6 %** du vocabulaire. Il s'agit de formes verbales rares (signala, rasa, arrimé), de noms propres secondaires (calasareigne, phocée, trieste), de mots rares, et de bruit (produced, chuck, www). Ils sont peu utiles statistiquement (une seule observation) et alourdissent les matrices, mais certains sont très informatifs pour caractériser un passage précis.",
])
A.append([
 "## Q1. Les 20 mots les plus fréquents sont-ils informatifs ?",
 "Non : ce sont des mots grammaticaux (de, le, et, la, à, il, que…) communs à tout texte français. Ils renseignent sur la langue, pas sur le roman. Seul « dit » (16e) reflète un trait du texte : la forte présence de dialogues.",
 "## Q2. Loi de Zipf",
 "La fréquence d'un mot est approximativement inversement proportionnelle à son rang : f(r) ≈ C / r. Conséquences pour le NLP : quelques mots très fréquents (stop words) occupent une grande part du texte, tandis qu'une majorité de mots sont rares (longue traîne). D'où l'intérêt de filtrer les mots très fréquents, de pondérer (IDF), de limiter le vocabulaire (min_df, max_features), et la difficulté de bien représenter les mots rares (problème de données éparses).",
 "## Q3. Hapax",
 "Un hapax est un mot qui n'apparaît qu'une seule fois dans le corpus. Pour une analyse statistique (fréquences, BoW, clustering), on les supprime souvent (min_df=2) : ils sont nombreux, coûteux et sans valeur statistique, et contiennent des fautes ou du bruit. On les conserve en stylométrie, en recherche d'information (un mot rare peut identifier un passage précis) ou pour l'étude du vocabulaire d'un auteur.",
])

# ---------------- PARTIE 6
A.append([
 "## a) NLTK vs SpaCy",
 "NLTK : **157** stop words ; SpaCy : **507** ; **85** en commun. La liste SpaCy est la plus complète (adverbes et mots fréquents : abord, afin, ah, ainsi, alors, après, assez…). La liste NLTK contient surtout les conjugaisons d'avoir et être (aient, aurai, aviez, ayez, eue…) absentes de SpaCy. D'où l'intérêt de l'union des deux.",
 "Note : dans le sujet, l'union est écrite avec le caractère « │ » ; en Python il faut l'opérateur « | ».",
 "## b) Top 20 après filtrage",
 "dantès 777, qu'il 575, c'est 417, homme 364, morrel 273, villefort 258, d'un 253, jeune 236, faire 225, caderousse 219, edmond 214, d'une 209, l'abbé 201, père 195, j'ai 176, fois 167, danglars 166, rien 165, temps 161, fernand 161.",
 "Personnages visibles : **Dantès, Morrel, Villefort, Caderousse, Edmond, l'abbé (Faria), Danglars, Fernand**. Limite : des formes élidées (qu'il, c'est, d'un, j'ai) restent, car NLTK les garde collées et elles ne sont pas dans les listes. Amélioration : séparer les élisions avant le filtrage ou les ajouter aux stop words.",
 "Amélioration testée (fonction separer_elisions) : en séparant « qu' », « c' », « d' »… puis en les ajoutant aux stop words, le top 20 devient : dantès 777, homme 425, morrel 273, villefort 258, edmond 247, jeune 236, faire 225, caderousse 219, abbé 214, père 195, fois 167, danglars 166, rien 165, temps 161, fernand 161, demanda 155, yeux 154, jour 144, fit 141, point 139. Les formes élidées ont disparu et « abbé » remonte (214).",
 "## c) Taux de réduction",
 "123 589 → 54 738 tokens : **55,7 %** des tokens supprimés. Le vocabulaire, lui, ne baisse que de 3,7 % (11 973 → 11 526) : quelques centaines de mots très fréquents représentent plus de la moitié du texte (Zipf).",
 "## d) dit, répondit, monsieur",
 "Fréquences : dit = 938, monsieur = 333, répondit = 137. Ce sont des verbes d'introduction du dialogue et des formules de politesse répétées partout, qui écraseraient les mots thématiques dans le top et le WordCloud. Ils ne sont pas totalement non-informatifs : ils indiquent un roman très dialogué, et « monsieur » marque le registre social du XIXe siècle. Leur suppression est un choix lié à l'objectif (trouver les thèmes), pas une vérité absolue.",
 "## e) Personnages",
 ('TAB', [["Personnage", "Fréquence"],
          ["dantès", "777"], ["villefort", "258"], ["danglars", "166"], ["fernand", "161"],
          ["mercédès", "138"], ["faria", "105"]]),
 "**Dantès** est de loin le plus présent (et même 991 occurrences en ajoutant « edmond » 214). Morrel (273) et Caderousse (219), absents de la liste, sont aussi très présents.",
])
A.append([
 "## Q1. Mots disparus",
 "Les articles, prépositions, pronoms, conjonctions et auxiliaires (de, le, et, la, à, il, que, vous…) ainsi que les mots ajoutés (dit, monsieur, bien, tout…). Ils sont indispensables à la grammaire mais inutiles pour identifier les thèmes : leur suppression fait apparaître les personnages en tête du classement.",
 "## Q2. Stop words spécifiques au domaine",
 "Certains mots sont fréquents uniquement dans un type de texte et y deviennent du bruit : dans un roman du XIXe siècle « dit, répondit, monsieur » ; dans des avis clients « produit, achat » ; dans des textes juridiques « article, alinéa ». Ils ne permettent pas de distinguer les documents entre eux.",
 "## Q3. Tâche où il ne faut pas les supprimer",
 "Analyse de sentiment : « ne… pas », « sans » inversent le sens (« pas content »). Aussi la traduction automatique, la génération de texte, les questions-réponses, la détection de l'auteur (stylométrie, qui repose justement sur la fréquence des mots grammaticaux) et les modèles de type BERT qui ont besoin de phrases complètes.",
 "## Q4. Réversible ?",
 "Non : une fois supprimés, on ne peut pas reconstruire la phrase. « Dantès fut emprisonné au château d'If » devient « dantès emprisonné château d'if » : le sens général reste devinable, mais la négation, le temps, les relations (qui fait quoi à qui) sont perdus. Il faut donc conserver le texte original à côté.",
])

# ---------------- PARTIE 7
A.append([
 "## a) WordCloud du roman",
 "IMG:07_wordcloud_roman.png",
 "Les 5 mots les plus visibles : **dantès, qu'il, homme, c'est, morrel**. C'est cohérent (le héros et l'armateur Morrel, protecteur de Dantès, dominent le Tome I), mais « qu'il » et « c'est » montrent que les élisions auraient dû être filtrées.",
 "## b) WordClouds par personnage",
 "IMG:07_wordcloud_personnages.png",
 "- Dantès : abbé, villefort, yeux, temps, point → la prison et le dialogue avec l'abbé Faria.",
 "- Danglars : caderousse, fernand, morrel, capitaine → le complot et la rivalité sur le Pharaon.",
 "- Villefort : père, renée, lettre, main, morrel → sa carrière, son mariage avec Renée, la lettre compromettante de son père Noirtier.",
 "## c) Noms propres (PROPN)",
 "IMG:07_wordcloud_noms_propres.png",
 "Personnages : Dantès (349), Morrel (272), Villefort (255), Edmond (243), Caderousse (184), Danglars (157), Fernand (153), Mercédès (118), Franz (71), Jacopo (41), Faria (40), Gaetano (32). Lieux : Marseille (74), Paris (40), France (37), l'île d'Elbe (35), Monte-Cristo (« Monte » 42 / « Cristo » 41, coupé en deux). Contexte : Dieu (122), Louis, Majesté, Napoléon. Quelques erreurs du modèle (« mer », « rocher » étiquetés PROPN).",
 "## d) Paramètres",
 "IMG:07_wordcloud_max_words.png",
 "max_words=50 est le plus lisible : chaque mot est grand et les thèmes se lisent en un coup d'œil ; avec 200 mots on obtient beaucoup de petits mots illisibles. La palette RdYlGn est peu lisible sur fond blanc (les mots jaunes contrastent mal) ; une palette séquentielle foncée est préférable.",
 "## e) Début vs fin",
 "IMG:07_wordcloud_debut_fin.png",
 "Début : dantès, père, jeune, capitaine, morrel, danglars, l'armateur, edmond, caderousse, vieillard, fils → Marseille, l'arrivée du Pharaon, le père de Dantès. Fin : franz, gaetano, simbad, homme, yeux, monde, vie (et contrebandier, hachisch) → l'épisode de l'île de Monte-Cristo où Franz d'Épinay rencontre « Simbad le marin ». Le vocabulaire change complètement : le héros n'est plus nommé « Dantès » mais apparaît sous un pseudonyme, ce qui révèle la structure en deux temps (la chute de Dantès, puis la réapparition du comte).",
])
A.append([
 "## Q1. Limites des WordClouds",
 "Utiles pour explorer, insuffisants pour analyser : pas de valeurs chiffrées précises, taille difficile à comparer, ordre et contexte ignorés (« vengeance » et « pas de vengeance » sont pareils), mots composés coupés (monte / cristo), résultat très dépendant du prétraitement, couleurs et placement sans signification.",
 "## Q2. Thèmes dominants",
 "Les personnages et leurs relations (Dantès, Morrel, Villefort, Danglars, Fernand, Caderousse, Mercédès), la famille (père, fils), la mer et le commerce maritime (capitaine, armateur, Pharaon, marin), la justice et la prison (roi, prison, prisonnier, château d'If), le contexte politique (Napoléon, Louis XVIII, île d'Elbe).",
 "## Q3. Pourquoi supprimer les stop words avant ?",
 "Parce que la taille d'un mot est proportionnelle à sa fréquence : sans filtrage, le nuage serait occupé par « de, le, et, la, à » (les mots les plus fréquents) et ne montrerait rien du contenu du roman.",
])

# ---------------- PARTIE 8
A.append([
 "## a) Familles de mots",
 ('TAB', [["Famille", "Formes → racine", "Même racine ?"],
          ["vengeance", "vengeance→vengeanc, venger→veng, vengeur→vengeur, vindicatif→vindiqu", "Non (4 racines)"],
          ["prison", "prison→prison, prisonnier→prisonni, emprisonner→emprison, emprisonnement→emprison", "Non (3 racines)"],
          ["liberté", "liberté→libert, libérer→liber, libérateur→liber, libération→liber", "Presque (2 racines)"],
          ["mer", "mer→mer, marin→marin, maritime→maritim, navire→navir, naviguer→navigu", "Non"]]),
 "Le stemmer ne regroupe que les formes qui ont exactement le même début ; il ne connaît pas l'étymologie (vindicatif, mer/marin) ni les préfixes (em-prison).",
 "## b) Réduction du vocabulaire",
 "11 526 mots → **6 409 racines**, soit **−44,4 %**. Le gain est significatif, surtout grâce aux conjugaisons (ex. 20 formes regroupées sous « trouv » : trouva, trouvait, trouvant, trouve…).",
 "## c) Faux amis du stemmer",
 "- « port » (le port de Marseille) et « portait », « porta » (verbe porter) → racine **port**.",
 "- « sort » (le destin) et « sortait », « sorti » (verbe sortir) → racine **sort**.",
 "- « mont » (montagne) et « montait », « monta » (verbe monter) → racine **mont** ; de même « don » (cadeau) et « donnait » → **don**.",
 "## d) Tableau",
 ('TAB', [["Mot original", "Radical (Snowball)", "Intelligible ?"],
          ["vengeance", "vengeanc", "Oui"], ["prisonnier", "prisonni", "Oui"],
          ["liberté", "libert", "Oui"], ["navire", "navir", "Oui"],
          ["capitaine", "capitain", "Oui"], ["château", "château", "Oui"],
          ["trésor", "trésor", "Oui"], ["chevaux", "cheval", "Oui"],
          ["yeux", "yeux", "Oui, mais non relié à « œil »"], ["allaient", "allaient", "Non regroupé avec aller"],
          ["fut", "fut", "Non relié à « être »"], ["heureux", "heureux", "Oui"],
          ["jeunesse", "jeuness", "Moyen"], ["catalans", "catalan", "Oui"],
          ["mercédès", "mercédes", "Altéré (accent perdu)"]]),
 "## e) Racines thématiques",
 "veng- : 19 ; pris- : 251 ; liber- : 49 ; dant- : 780. Le thème dominant est le personnage de Dantès. Le chiffre de « pris- » est trompeur : il inclut « pris », participe du verbe prendre (autre faux ami). En ne gardant que prison/prisonni, le thème carcéral reste nettement devant la liberté et la vengeance dans ce Tome I.",
])
A.append([
 "## Q1. Avantages",
 "Regroupe les variantes d'un mot (conjugaisons, pluriels), réduit fortement le vocabulaire (−44 % ici), rend les matrices plus petites et moins creuses, augmente le rappel en recherche d'information (« prisonniers » retrouve « prisonnier »). Il est très rapide et ne nécessite pas de dictionnaire.",
 "## Q2. Limites (exemples)",
 "- Sur-racinisation (mots différents fusionnés) : port / portait, sort / sortait, pris / prison.",
 "- Sous-racinisation (même mot non regroupé) : venger→veng et vengeance→vengeanc ; fut ≠ être ; yeux ≠ œil ; allaient ≠ aller.",
 "- Racines illisibles ou altérées : jeuness, vindiqu, mercédès → mercédes.",
 "## Q3. Snowball vs Porter",
 "Porter a été conçu uniquement pour l'anglais (suffixes -ing, -ed, -ness). Snowball est un cadre multilingue qui fournit des règles propres au français (suffixes -ement, -ation, -issement, terminaisons verbales, accents).",
 "## Q4. Stemming plutôt que lemmatisation",
 "Pour de grands volumes et quand la vitesse compte plus que la précision : moteur de recherche, indexation, classification de millions de documents, ou langue sans bon lemmatiseur. La lisibilité des racines n'importe alors pas.",
])

# ---------------- PARTIE 9
A.append([
 "## a) SpaCy sur le chapitre I",
 "Chapitre I (« Marseille. — L'arrivée », de « Le 24 février 1815 » jusqu'au titre du chapitre II) : 18 849 caractères, **4 088 tokens**. Extrait du DataFrame : Le/le/DET, 24/24/NUM, février/février/NOUN, 1815/NUM, la/le/DET, vigie/NOUN, Notre-Dame/PROPN, signala/**ADJ** (erreur : c'est le verbe signaler), trois-mâts/NOUN, Pharaon/PROPN, venant/**venir**/VERB…",
 "## b) Top 15 noms (NOUN lemmatisés)",
 "monsieur 32, armateur 28, homme 19, capitaine 15, **dantè 13**, bâtiment 11, île 9, père 9, œil 8, ordre 7, pilote 6, port 6, navire 6, fils 6, paquet 6.",
 "Le vocabulaire est maritime (armateur, capitaine, bâtiment, pilote, port, navire). Erreur notable : « Dantès » est parfois étiqueté NOUN et lemmatisé en « dantè » (le modèle le prend pour un pluriel).",
 "## c) Noms propres (PROPN)",
 "Morrel 21, Danglars 17, Dantès 14, Leclère 10, Edmond 10, Pharaon 8, Elbe 4, Marseille 3, Porto-Ferrajo 3, Mercédès 3, Paris 3, Naples 2, Notre-Dame. On retrouve les personnages du chapitre (l'armateur Morrel, le comptable Danglars, le capitaine Leclère décédé) et les lieux (Marseille, l'île d'Elbe, Porto-Ferrajo). Erreurs : « « », « - », « jeta » classés PROPN.",
 "Distribution POS : NOUN 16,5 %, PUNCT 15,9 %, PRON 12,2 %, ADP 11,1 %, VERB 10,8 %, DET 10,1 %, ADV 5,8 %, ADJ 4,9 %, PROPN 3,9 %, AUX 3,3 %.",
 "## d) Stemming vs lemmatisation",
 ('TAB', [["Mot", "Stemming", "Lemme (SpaCy)", "Correct ?"],
          ["navire", "navir", "navire", "Lemme"], ["prisonnier", "prisonni", "prisonnier", "Lemme"],
          ["vengeance", "vengeanc", "vengeance", "Lemme"], ["chevaux", "cheval", "cheval", "Les deux"],
          ["yeux", "yeux", "oeil", "Lemme"], ["allaient", "allaient", "aller", "Lemme"],
          ["fut", "fut", "être", "Lemme"], ["meilleurs", "meilleur", "meilleur", "Les deux*"],
          ["emprisonné", "emprison", "emprisonner", "Lemme"], ["libérés", "liber", "libérer", "Lemme"],
          ["heureux", "heureux", "heureux", "Les deux"], ["faisait", "fais", "faire", "Lemme"],
          ["jeunesse", "jeuness", "jeunesse", "Lemme"], ["pouvait", "pouv", "pouvoir", "Lemme"],
          ["mers", "mer", "mer", "Les deux"]]),
 "*SpaCy donne « meilleur » et non « bon » comme indiqué dans l'encadré du sujet : le comparatif n'est pas ramené à son adjectif de base.",
 "## e) Méthode la plus adaptée à l'analyse littéraire",
 "La **lemmatisation**, car on veut des résultats lisibles et justes : « fut » → être (le stemmer garde « fut », il ne retrouve pas le verbe), « yeux » → œil (le stemmer ne les relie pas, alors que « les yeux » est un motif fréquent du roman), « allaient » → aller et « faisait » → faire (le stemmer donne « allaient » et « fais »). Elle évite aussi les confusions port/porter et sort/sortir.",
])
A.append([
 "## Q1. Différence fondamentale",
 "Le stemming coupe les suffixes par des règles, sans connaître la langue ni le contexte : le résultat n'est pas forcément un mot. La lemmatisation utilise un dictionnaire et l'analyse grammaticale pour retourner la forme canonique (infinitif, masculin singulier) : le résultat est toujours un vrai mot.",
 "## Q2. « vole »",
 "« vole » peut être le verbe voler (lemme voler) ou le nom vol / la forme d'un nom ; seul le POS permet de choisir le bon lemme. Résultat obtenu avec le petit modèle fr_core_news_sm : « L'oiseau vole » → ADJ, lemme « vol » ; « Il vole de l'argent » → NOUN, lemme « vole ». Les deux sont faux : le lemme correct serait « voler » (VERB). Cela montre que la lemmatisation dépend entièrement de la qualité de l'étiquetage ; un modèle plus grand (fr_core_news_lg) ou un transformeur (fr_dep_news_trf) ferait mieux.",
 "## Q3. Corpus littéraire du XIXe siècle",
 "La lemmatisation, malgré ses erreurs, car le texte est riche en passés simples et imparfaits (fut, allaient, jeta, signala) que le stemmer ne regroupe pas. Limites : les modèles sont entraînés sur des textes modernes, d'où des erreurs sur les formes rares (« signala » → ADJ) et les noms propres (« Dantès » → « dantè »).",
 "## Q4. Coût computationnel",
 "Sur ce TP, la tokenisation NLTK du tome entier prend moins d'une seconde, alors que SpaCy (avec étiquetage) met environ 12 secondes pour le tome complet. SpaCy est plus lent car il applique un réseau de neurones (POS, dépendances, NER). Le compromis est acceptable quand la qualité linguistique compte (analyse littéraire, extraction d'information) ou quand le corpus est de taille raisonnable ; sinon on désactive les composants inutiles (nlp.pipe(..., disable=['parser','ner'])) ou on utilise NLTK.",
])

# ---------------- PARTIE 10
A.append([
 "## a) Dimensions",
 "**20 documents × 300 mots**. Attention : le code du sujet ne prend que les 20 premiers blocs de 2 000 mots, soit 40 000 mots sur 123 589 (environ le premier tiers du tome, jusqu'aux Cent-Jours).",
 "## b) Ligne, colonne, cellule",
 "Une ligne = un document (un bloc de 2 000 mots). Une colonne = un mot du vocabulaire retenu. Une cellule = nombre d'occurrences de ce mot dans ce bloc.",
 "## c) Vocabulaire le plus riche",
 "Sur le texte complet des blocs : **Bloc_07** (814 mots distincts), devant Bloc_16 (801) et Bloc_14 (780). Parmi les 300 colonnes de la matrice : Bloc_11 (158 colonnes non nulles).",
 "## d) Personnages par bloc",
 ('TAB', [["Personnage", "Bloc max", "Occurrences", "Correspondance"],
          ["dantès", "Bloc_13", "29", "arrestation et interrogatoire par Villefort"],
          ["danglars", "Bloc_05", "27", "le complot à la Réserve"],
          ["villefort", "Bloc_10", "29", "le substitut du procureur, chez les Saint-Méran"],
          ["mercédès", "Bloc_04", "22", "les Catalans"],
          ["fernand", "Bloc_05", "29", "le complot"],
          ["faria", "aucun", "0", "1re apparition au mot n° 45 171, soit ≈ bloc 23, hors des 20 blocs"]]),
 "Oui, les pics correspondent aux chapitres où les personnages agissent. Faria n'apparaît pas car il n'entre en scène qu'après la partie analysée (et le mot n'est donc pas dans le vocabulaire de la matrice).",
 "Pour aller plus loin, j'ai compté les personnages par chapitre sur l'ensemble du tome (31 chapitres) :",
 "IMG:07_personnages_chapitres.png",
 "Faria est présent des chapitres XIV à XX (la captivité au château d'If). Dans les chapitres XXIX et XXX, c'est Morrel qui domine (69 et 97 occurrences : la ruine de la maison Morrel), et dans le chapitre XXXI seul Franz apparaît (73 occurrences). « dantès » vaut 0 dans ces trois derniers chapitres : le héros agit sous d'autres identités.",
 "## e) Heatmap",
 "IMG:10_heatmap_bow.png",
 "Trois phases nettes : blocs 1–9 à Marseille (dantès, danglars, fernand, caderousse, mercédès : la fête et le complot), blocs 9–16 autour de Villefort (l'interrogatoire et le château d'If), blocs 16–20 à Paris aux Tuileries (roi, sire, Louis XVIII). La distribution des mots suit l'intrigue.",
 "## f) Sparsité",
 "Avec 300 colonnes : densité 46,4 %, donc **53,6 % de cellules à 0**. Avec le vocabulaire complet (4 960 mots) : **89,2 % de zéros**. Problème : beaucoup de mémoire et de calcul perdus, des distances peu significatives en grande dimension (malédiction de la dimension), et des algorithmes comme k-NN, k-means ou les réseaux de neurones qui fonctionnent mal sur des vecteurs presque vides.",
])
A.append([
 "## Q1. Ligne / colonne",
 "Une ligne est le vecteur d'un document (sa « signature » en nombre d'occurrences) ; une colonne est la distribution d'un mot sur l'ensemble des documents.",
 "## Q2. Pourquoi creuse ?",
 "Le vocabulaire total est grand (des milliers de mots) mais chaque document n'en utilise qu'une petite partie. Avec la loi de Zipf, la plupart des mots sont rares et n'apparaissent que dans un ou deux documents : la majorité des cellules valent 0.",
 "## Q3. Avantages du BoW",
 "Très simple à comprendre et à calculer, interprétable (chaque colonne est un mot), efficace en stockage creux, base suffisante pour de nombreuses tâches (classification de textes, filtrage de spam, recherche simple).",
 "## Q4. Informations perdues",
 "L'ordre des mots et la syntaxe (« Danglars dénonce Dantès » = « Dantès dénonce Danglars »), le contexte et la négation, le sens (synonymes « navire » et « bâtiment » sont deux colonnes indépendantes), et l'importance relative des mots (un mot fréquent partout pèse autant qu'un mot discriminant).",
])

# ---------------- PARTIE 11
A.append([
 "## a) Matrice TF-IDF",
 "Dimensions (20, 300). Scores les plus élevés du Bloc_01 : navire 0,2005 ; armateur 0,1907 ; bâtiment 0,1807 ; morrel 0,1798 ; leclère 0,1751 ; marin 0,1721 ; empereur 0,1637 ; danglars 0,1551 ; arrivé 0,1515 ; capitaine 0,1514.",
 "## b) 5 mots signatures par bloc",
 ('TAB', [["Bloc", "Top 5 TF-IDF", "Bloc", "Top 5 TF-IDF"],
          ["01", "navire, armateur, bâtiment, morrel, leclère", "11", "renée, marquise, villefort, procureur, morrel"],
          ["02", "vieillard, armateur, leclère, danglars, capitaine", "12", "villefort, bonheur, juge, justice, dantès"],
          ["03", "caderousse, vieillard, argent, danglars, capitaine", "13", "gendarmes, commissaire, villefort, juge, justice"],
          ["04", "fernand, mercédès, ennemi, aime, catalan", "14", "barque, geôlier, château, if, gendarmes"],
          ["05", "caderousse, fernand, danglars, mercédès, vin", "15", "geôlier, gouverneur, marquis, impossible, prisonnier"],
          ["06", "fernand, caderousse, danglars, papier, santé", "16", "cabinet, sire, villefort, juge, renée"],
          ["07", "fernand, caderousse, danglars, repas, mari", "17", "duc, sire, blacas, majesté, baron"],
          ["08", "commissaire, danglars, caderousse, fernand, vieillard", "18", "sire, ministre, blacas, police, xviii"],
          ["09", "napoléon, danglars, marquise, caderousse, fernand", "19", "quesnel, ministre, général, sire, villefort"],
          ["10", "marquise, renée, villefort, marquis, salvieux", "20", "général, quesnel, noirtier, police, villefort"]]),
 "Oui, ils résument très bien chaque bloc : arrivée du navire (01), le vieux père (02), les Catalans et l'amour de Fernand pour Mercédès (04), le complot avec le vin et le papier (05–07), l'arrestation (08, 13), le transfert au château d'If (14), la prison (15), la cour de Louis XVIII avec Blacas (17–18), le général Quesnel et Noirtier (19–20).",
 "## c) Similarité cosinus",
 "IMG:11_similarite_cosinus.png",
 "Paires les plus proches : Bloc_17–Bloc_18 (**0,71**, cour du roi), Bloc_07–Bloc_08 (0,64, repas de fiançailles et arrestation), Bloc_17–Bloc_19 (0,63), Bloc_05–Bloc_06 (0,61, complot). Paires les plus éloignées : Bloc_07–Bloc_18 (0,20) et Bloc_14–Bloc_18 (0,20) : Marseille ou la prison face aux Tuileries. La diagonale en blocs montre que les passages voisins traitent du même thème.",
 "## d) Mini-moteur de recherche",
 "CODE:requete = 'château if prison dantès'  ->  [('Bloc_14', 0.362), ('Bloc_15', 0.220), ('Bloc_01', 0.210)]",
 "Le Bloc_14 (barque, geôlier, château, if, gendarmes) est exactement le passage où Dantès est conduit au château d'If ; le Bloc_15 (geôlier, gouverneur, prisonnier) est sa détention. Résultat pertinent.",
 "## e) BoW vs TF-IDF pour le Bloc_01",
 "BoW : dantès, morrel, armateur, capitaine, bâtiment, île, navire, danglars, marin, arrivé. TF-IDF : navire, armateur, bâtiment, morrel, leclère, marin, empereur, danglars, arrivé, capitaine.",
 "Le TF-IDF est **plus discriminant** : « dantès », présent dans 17 blocs sur 20 (IDF 1,21), passe de la 1re place à une place secondaire (BoW 17 → TF-IDF 0,129), alors que « danglars » (IDF 1,74), moins répandu, obtient un score plus élevé (0,155) avec seulement 9 occurrences. Des mots propres au bloc comme « leclère » et « empereur » apparaissent : ils caractérisent ce passage précis.",
])
A.append([
 "## Q1. Pourquoi TF-IDF est meilleur pour la recherche",
 "Il donne peu de poids aux mots présents partout (qui ne permettent pas de choisir entre les documents) et beaucoup aux mots rares et spécifiques de la requête. Avec la similarité cosinus, il normalise aussi la longueur des documents.",
 "## Q2. Score TF-IDF élevé",
 "Le mot est fréquent dans ce document et rare dans les autres : il est caractéristique du document (ex. « geôlier » dans le Bloc_15, « blacas » dans le Bloc_17).",
 "## Q3. Similarité cosinus",
 "C'est le cosinus de l'angle entre deux vecteurs : cos = (A·B) / (‖A‖ × ‖B‖). Elle mesure l'orientation (proportion des mots) indépendamment de la longueur. Avec des scores TF-IDF positifs, elle varie de 0 (aucun mot en commun) à **1 (similarité totale)**.",
 "## Q4. Mauvais résultats possibles",
 "- Synonymes : « navire » et « bâtiment » ne se rapprochent pas, une requête « vaisseau » ne trouve rien.",
 "- Mots polysémiques ou mots importants présents partout : « dantès » est pénalisé alors qu'il est central.",
 "- Requêtes avec un mot absent du vocabulaire (max_features=300, min_df=2) : score nul.",
 "- Documents très courts, négation et ordre des mots ignorés, ironie.",
])

# ---------------- SYNTHÈSE FINALE Q1–Q6
A.append([
 ('TAB', [["Étape", "Objectif", "Entrée → sortie"],
          ["1. Chargement", "Obtenir le texte de l'œuvre sans les métadonnées", "URL / fichier → chaîne Python (727 635 car.)"],
          ["2. Nettoyage", "Supprimer le bruit et uniformiser (minuscules, ponctuation, nombres)", "texte brut → texte normalisé (695 557 car.)"],
          ["3. Tokenisation", "Découper en unités d'analyse", "texte → liste de tokens (123 589)"],
          ["4. Fréquences", "Mesurer l'importance statistique des mots, vérifier Zipf", "tokens → compteur (mot, fréquence)"],
          ["5. Stop words", "Retirer les mots grammaticaux peu informatifs", "tokens → tokens filtrés (54 738)"],
          ["6. WordCloud", "Explorer visuellement les thèmes", "tokens filtrés → image"],
          ["7. Stemming", "Regrouper les variantes par troncature", "tokens → racines (6 409 types)"],
          ["8. Lemmatisation", "Ramener chaque mot à sa forme canonique grâce au POS", "tokens → lemmes + catégories"],
          ["9. BoW", "Représenter les documents par des vecteurs de comptes", "blocs de texte → matrice 20 × 300"],
          ["10. TF-IDF", "Pondérer les mots selon leur pouvoir discriminant", "blocs → matrice pondérée → similarités, recherche"]]),
])
A.append([
 "Le **nettoyage** modifie le contenu du texte (supprime ou remplace des caractères) ; la **tokenisation** ne change pas le contenu mais le découpe en unités. Le premier produit une chaîne, la seconde une liste.",
 "- Tokeniser sans nettoyer : oui, c'est courant (SpaCy, BERT tokenisent le texte brut, et la ponctuation devient des tokens). C'est même nécessaire pour le POS, la NER ou la segmentation en phrases.",
 "- Nettoyer sans tokeniser : oui, le nettoyage s'applique à une chaîne (regex), mais il n'aboutit à aucune analyse : on ne peut pas compter, filtrer ou vectoriser sans tokens.",
 "L'ordre compte : nettoyer avant de tokeniser en phrases détruit les phrases (1 seule phrase trouvée au lieu de 237 sur notre extrait).",
])
A.append([
 "Dans ce roman très dialogué, « dit » (938 occurrences), « répondit » (137) et « monsieur » (333) sont des formules répétitives qui introduisent les répliques ou marquent la politesse. Ils dominaient le classement et le WordCloud sans rien dire des thèmes ; les retirer fait ressortir les personnages et les lieux.",
 "Pour des **tweets** ou des **avis clients**, ces mots-là seraient rares (pas de « répondit », peu de « monsieur ») : inutile de les ajouter. Il faudrait au contraire des stop words propres à ces corpus (rt, lol, produit, commande, livraison si tous les avis en parlent). Et attention : dans les avis, il ne faut pas supprimer les négations (« ne… pas », « jamais ») qui portent le sentiment.",
])
A.append([
 "Le stemming tronque par des règles (rapide, réduction de 44 % du vocabulaire, mais racines parfois illisibles et confusions) ; la lemmatisation utilise le dictionnaire et le POS (plus lente, mais résultats corrects et lisibles). Trois exemples du roman où la lemmatisation est meilleure :",
 "- « fut » (« Edmond Dantès fut injustement emprisonné ») : stemming « fut », lemme **être**.",
 "- « yeux » (très fréquent dans le roman) : stemming « yeux », lemme **œil**.",
 "- « allaient » / « faisait » : stemming « allaient » / « fais », lemmes **aller** / **faire**.",
 "Elle évite aussi des confusions du stemmer comme port/porter et sort/sortir. Limite observée : SpaCy lemmatise parfois « Dantès » en « dantè ».",
])
A.append([
 "En BoW, un bloc qui contient « dantès » 29 fois pèse lourd sur ce mot, alors que « dantès » est présent dans 17 blocs sur 20 : il ne permet pas de retrouver un passage précis. TF-IDF réduit son poids (IDF 1,21) et augmente celui des mots rares comme « geôlier », « if » ou « barque ».",
 "Exemple : pour la requête « château if prison dantès », TF-IDF classe en tête le **Bloc_14** (score 0,362), le passage du transfert au château d'If, parce que « château » et « if » y sont concentrés. En BoW, les blocs où Dantès est le plus nommé (Bloc_13) seraient favorisés même s'ils ne parlent pas du château d'If. TF-IDF met en avant ce qui distingue un document, ce qui est exactement le but d'un moteur de recherche.",
])
A.append([
 "Trois questions hors de portée de BoW et TF-IDF :",
 "- Le sens et les relations : « Qui a dénoncé Dantès et pourquoi ? » (« Danglars dénonce Dantès » et « Dantès dénonce Danglars » ont le même vecteur).",
 "- L'identité des personnages : « Simbad le marin, l'abbé Busoni et le comte sont-ils la même personne ? » (coréférence et synonymie).",
 "- Le ton et l'évolution : « Le comte éprouve-t-il de la haine ou de la pitié envers Mercédès ? » ; « Les propos de Danglars au repas sont-ils ironiques ? » ; « Dans quel ordre se déroulent les événements ? » (temporalité ignorée).",
 "Approches modernes : **Word2Vec / GloVe** pour rapprocher les synonymes (navire ≈ bâtiment) ; **BERT / CamemBERT / FlauBERT** (embeddings contextuels) pour la coréférence, la NER, le sentiment et les questions-réponses, en tenant compte du contexte et de l'ordre ; **GPT** (grands modèles génératifs) pour résumer l'intrigue, répondre à des questions sur le récit et interpréter l'ironie ou les intentions.",
])

# Colonne « Votre évaluation » du tableau de synthèse
EVAL = [
 "Confirmé : BoW = un comptage ; TF-IDF ajoute une seule pondération (IDF).",
 "Vérifié : TF-IDF fait baisser « dantès » (présent partout) et monter « leclère », « geôlier ».",
 "Vérifié : aucun des deux ne distingue « Danglars dénonce Dantès » de l'inverse.",
 "TF-IDF plus discriminant : signatures de blocs nettes, recherche « château d'If » → Bloc_14.",
 "Même taille (20 × 300) ; 53,6 % de zéros, 89,2 % sans max_features.",
 "Les deux sont lisibles (un mot par colonne) ; les scores TF-IDF sont un peu moins intuitifs.",
 "Vérifié : « monte » et « cristo » sont séparés, l'ordre est perdu (d'où l'intérêt des n-grammes).",
 "50,6 % d'hapax : min_df=2 les retire dans les deux cas ; l'IDF les valoriserait sinon.",
 "BoW pour une première exploration ; TF-IDF pour le mini-moteur de recherche du TP.",
 "CamemBERT / FlauBERT pour le français ; SBERT pour comparer des passages.",
]
